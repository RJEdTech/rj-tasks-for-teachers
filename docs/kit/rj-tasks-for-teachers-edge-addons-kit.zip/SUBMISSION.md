# RJ Tasks for Teachers: Microsoft Edge Add-ons submission

Copy each field into Partner Center (Edge > Overview > Create new extension).

## Package
Upload: `rj-tasks-for-teachers-1.0.1.zip` (manifest.json is at the root of the zip)
SHA-256: 25cceda20b70a0926483171ddfabfc02d17ed2f27f5d3b6f3ced40bd3fcabfaa

## Availability
- Visibility: **Hidden**
- Markets: **United States** only (Change markets > clear all > United States)

## Properties
- Category: **Productivity**
- Website: https://rjedtech.github.io/rj-tasks-for-teachers/
- Support contact: https://rjedtech.github.io/rj-tasks-for-teachers/#ideas
- Mature content: leave unchecked

## Privacy
Single purpose description:
Shows a Regis Jesuit High School teacher, inside the school's Canvas site (rjhs.instructure.com), what is waiting to be graded, course setup problems, students with missing work, and what is due this week in the classes they teach.

Permission justification, storage:
Saves the teacher's display settings (missing-work threshold, whether student names start hidden, classes to leave out, where the button appears), the ids of check-up items they chose to ignore, and the names of the classes they teach so the settings page can list them. No student names, work or grades are stored.

Host access justification (content script on https://rjhs.instructure.com/*):
RJ Tasks for Teachers runs only on Regis Jesuit's Canvas site. Using the teacher's existing Canvas session, it sends GET requests to seven Canvas API endpoints (courses, assignments, assignment groups, submissions, grading periods, course users, to-do count) for classes the teacher teaches, and shows the results on the page. It never creates, changes or deletes anything in Canvas, and it makes no requests to any other host.

Remote code: **No**. All code is in the package (Manifest V3, script-src 'self', no third-party runtime libraries).

Data usage: select **none** of the data types. The extension processes the teacher's Canvas data in the browser only; nothing is collected, transmitted to the developer, sold, or shared. Certify all three statements.

Privacy policy URL: https://rjedtech.github.io/rj-tasks-for-teachers/privacy.html

## Store listing (English)
Extension name and short description come from the manifest:
- Name: RJ Tasks for Teachers
- Short description: Grading, course check-ups and missing-work follow-up for Regis Jesuit teachers, inside Canvas.

Description:
RJ Tasks for Teachers is the Canvas companion for Regis Jesuit High School faculty. A My Classes button in the corner of Canvas opens a panel for all your classes, or just the one you're in.

To grade lists every assignment with submissions waiting, across all your sections, oldest wait first, with late, resubmitted and quiz answers to review marked. One click opens SpeedGrader.

Check-up catches setup problems before students do: assignments with no due date, unpublished work that's already due, lock dates before due dates, 0-point assignments, 12:00 AM due times, and assignment group weights that don't add up to 100%.

Students lists students with several missing assignments this grading period, using Canvas's own Missing flag. Names stay hidden until you click Show names, so it's safe on a projector, and Copy list gives you plain text for an email.

Week shows what's due from your classes each of the next seven days and flags any day where one class or section has two or more graded items due.

RJ Tasks for Teachers is read-only: it never changes anything in Canvas. It works only on Regis Jesuit's Canvas site (rjhs.instructure.com), collects no data, shows no ads and makes no requests to any other site.

Made by Regis Jesuit Ed Tech. Not affiliated with Instructure.

Logo: `logo-300.png` (300 x 300)
Small promotional tile: `promo-tile-440x280.png`
Screenshots (1280 x 800), in this order:
1. `screenshot-1-to-grade.png`
2. `screenshot-2-check-up.png`
3. `screenshot-3-students.png`
4. `screenshot-4-week.png`
5. `screenshot-5-settings.png`

Search terms: Canvas, Regis Jesuit, teachers, grading, SpeedGrader, missing work, course check

## Notes for certification
RJ Tasks for Teachers is an internal tool for Regis Jesuit High School (Colorado). It runs only on the school's Canvas LMS site, https://rjhs.instructure.com, and does nothing on any other site. It is listed as Hidden and will be deployed to faculty laptops by the school through Intune.

To test:
1. Sign in at https://rjhs.instructure.com/login/canvas with the review account below.
2. On the Dashboard, click the My Classes button in the bottom-right corner. The panel shows To grade, Check-up, Students and Week for the sample course.
3. On the Students tab, click Show names. Open the extension's popup or Settings from the panel footer.

Review account: [username] / [password]
(A Canvas-only test teacher in one sandbox course with test students and sample assignments. It has no access to real student data and will be deactivated after certification.)

Permissions: storage only, plus a content script limited to https://rjhs.instructure.com/*. Read-only (GET requests only), no remote code, no analytics, no data collection. Public homepage, privacy policy and source code: https://rjedtech.github.io/rj-tasks-for-teachers/ and https://github.com/RJEdTech/rj-tasks-for-teachers
