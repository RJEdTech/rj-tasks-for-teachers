"use strict";
(() => {
  // src/lib/constants.ts
  var PRODUCT_NAME = "RJ Tasks for Teachers", ALLOWED_ORIGINS = ["https://rjhs.instructure.com"], REVIEW_COURSE_IDS = ["17272"], PD_COURSE_PATH = "/courses/5414";
  var PD_HELP = {
    missing_policy: "/courses/5414/pages/setting-up-our-automatic-missing-slash-late-policy-in-canvas"
  };

  // src/lib/canvasApi.ts
  var ID = "\\d{1,20}", ENDPOINTS = [
    /^\/api\/v1\/courses$/,
    new RegExp(`^/api/v1/courses/${ID}/assignments$`),
    new RegExp(`^/api/v1/courses/${ID}/assignment_groups$`),
    new RegExp(`^/api/v1/courses/${ID}/students/submissions$`),
    new RegExp(`^/api/v1/courses/${ID}/grading_periods$`),
    new RegExp(`^/api/v1/courses/${ID}/users$`),
    // 1.1: RJ Baseline checks in Check-up (read-only)
    new RegExp(`^/api/v1/courses/${ID}/modules$`),
    new RegExp(`^/api/v1/courses/${ID}/modules/${ID}/items$`),
    new RegExp(`^/api/v1/courses/${ID}/late_policy$`)
  ], CanvasApiError = class extends Error {
    constructor(message, status = 0) {
      super(message), this.name = "CanvasApiError", this.status = status;
    }
  };
  function onAllowedOrigin() {
    return ALLOWED_ORIGINS.includes(window.location.origin);
  }
  function assertId(id) {
    let s = String(id ?? "");
    if (!/^\d{1,20}$/.test(s)) throw new CanvasApiError("Rejected invalid id");
    return s;
  }
  function resolveApiUrl(pathOrUrl) {
    if (!onAllowedOrigin())
      throw new CanvasApiError("RJ Tasks for Teachers only runs on RJ Canvas");
    let url;
    try {
      url = new URL(pathOrUrl, window.location.origin);
    } catch {
      throw new CanvasApiError("Rejected malformed URL");
    }
    if (url.origin !== window.location.origin)
      throw new CanvasApiError("Rejected cross-origin request");
    if (url.username || url.password)
      throw new CanvasApiError("Rejected URL with credentials");
    if (!ENDPOINTS.some((re) => re.test(url.pathname)))
      throw new CanvasApiError("Rejected endpoint " + url.pathname);
    return url;
  }
  function parseCanvasJson(text) {
    let body = text.replace(/^while\(1\);/, "").trim();
    return body ? JSON.parse(body) : null;
  }
  function nextLink(linkHeader) {
    if (!linkHeader) return null;
    let re = /<([^>]+)>;\s*rel="([^"]+)"/g, m;
    for (; (m = re.exec(linkHeader)) !== null; ) if (m[2] === "next") return m[1];
    return null;
  }
  async function getPage(pathOrUrl) {
    let url = resolveApiUrl(pathOrUrl), res = await fetch(url.toString(), {
      method: "GET",
      headers: { Accept: "application/json+canvas-string-ids, application/json" },
      credentials: "same-origin",
      redirect: "error",
      cache: "no-store",
      referrerPolicy: "same-origin"
    }), text = await res.text();
    if (!res.ok) throw new CanvasApiError(`Canvas returned ${res.status}`, res.status);
    return { data: parseCanvasJson(text), next: nextLink(res.headers.get("link")) };
  }
  async function canvasGet(path) {
    return (await getPage(path)).data;
  }
  async function canvasGetAll(path, maxPages = 25) {
    let items = [], next = path, seen = /* @__PURE__ */ new Set();
    for (let i = 0; next; i++) {
      if (i >= maxPages) return { items, truncated: !0 };
      let url;
      try {
        url = resolveApiUrl(next).toString();
      } catch (err) {
        if (i === 0) throw err;
        return { items, truncated: !0 };
      }
      if (seen.has(url)) break;
      seen.add(url);
      try {
        let page = await getPage(url);
        if (!Array.isArray(page.data)) break;
        items.push(...page.data), next = page.next;
      } catch (err) {
        if (i === 0) throw err;
        return { items, truncated: !0 };
      }
    }
    return { items, truncated: !1 };
  }
  function canvasLink(template, ids) {
    let path = template.replace(/:(\w+)/g, (_, k) => assertId(ids[k])), url = new URL(path, window.location.origin);
    if (url.origin !== window.location.origin) throw new CanvasApiError("Rejected link");
    return url.toString();
  }
  async function mapLimit(items, limit, fn) {
    let out = new Array(items.length), i = 0, workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
      for (; i < items.length; ) {
        let idx = i++;
        out[idx] = await fn(items[idx]);
      }
    });
    return await Promise.all(workers), out;
  }

  // src/lib/dates.ts
  function parse(iso) {
    if (!iso) return null;
    let d = new Date(iso);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  function dayKey(d) {
    let y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, "0"), day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  function startOfDay(d) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  }
  function addDays(d, n) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  }
  function isLocalMidnight(d) {
    return d.getHours() === 0 && d.getMinutes() === 0 && d.getSeconds() === 0;
  }
  var dayFmt = new Intl.DateTimeFormat("en-US", { weekday: "short", month: "short", day: "numeric" }), timeFmt = new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" });
  function formatDay(d) {
    return dayFmt.format(d);
  }
  function formatDayTime(d) {
    return `${dayFmt.format(d)}, ${timeFmt.format(d)}`;
  }
  function waitingFor(since, now) {
    let days = Math.floor((startOfDay(now).getTime() - startOfDay(since).getTime()) / 864e5);
    return days <= 0 ? "today" : days === 1 ? "1 day" : `${days} days`;
  }
  function daysBetween(a, b) {
    return Math.round((startOfDay(b).getTime() - startOfDay(a).getTime()) / 864e5);
  }

  // src/data/courses.ts
  var TEACHING = /* @__PURE__ */ new Set(["teacher", "ta"]);
  function isCurrentTeachingCourse(c, now) {
    if (!c.enrollments?.some((e) => TEACHING.has(e.type)) || c.workflow_state !== void 0 && c.workflow_state !== "available") return !1;
    let end = (c.restrict_enrollments_to_course_dates ? parse(c.end_at) : null) ?? parse(c.term?.end_at ?? null);
    return !(end && end.getTime() < now.getTime());
  }
  var SEMESTER = /\b(1st|2nd)\s+semester\b/i;
  function isSemesterTerm(t) {
    let name = (t?.name ?? "").trim();
    return SEMESTER.test(name) && !/summer/i.test(name) && !/^x/i.test(name);
  }
  var LEAD_DAYS = 14;
  function isCurrentSemester(t, now) {
    if (!isSemesterTerm(t)) return !1;
    let start2 = parse(t.start_at ?? null), end = parse(t.end_at ?? null);
    return end && end.getTime() <= now.getTime() ? !1 : !start2 || start2.getTime() - LEAD_DAYS * 864e5 <= now.getTime();
  }
  function isShownCourse(c, now, allClasses = !1) {
    if (!isCurrentTeachingCourse(c, now)) return !1;
    if (allClasses || REVIEW_COURSE_IDS.includes(String(c.id))) return !0;
    if (!isSemesterTerm(c.term)) return !1;
    if (c.restrict_enrollments_to_course_dates && parse(c.end_at)) {
      let start2 = parse(c.term?.start_at ?? null);
      return !start2 || start2.getTime() - LEAD_DAYS * 864e5 <= now.getTime();
    }
    return isCurrentSemester(c.term, now);
  }
  function toTeacherCourse(c) {
    return {
      id: String(c.id),
      name: c.name || c.course_code || "Course",
      code: c.course_code || c.name || "Course",
      weighted: !!c.apply_assignment_group_weights,
      // Canvas enforces a course's own dates over the term's when this is set.
      termStart: ((c.restrict_enrollments_to_course_dates ? parse(c.start_at ?? null) : null) ?? parse(c.term?.start_at ?? null))?.getTime() ?? null,
      termEnd: ((c.restrict_enrollments_to_course_dates ? parse(c.end_at) : null) ?? parse(c.term?.end_at ?? null))?.getTime() ?? null
    };
  }
  function teacherCourses(all, now, excluded = [], allClasses = !1) {
    let skip = new Set(excluded.map(String));
    return all.filter((c) => isShownCourse(c, now, allClasses)).map(toTeacherCourse).filter((c) => !skip.has(c.id)).sort((a, b) => a.code.localeCompare(b.code, "en", { numeric: !0 }));
  }

  // src/data/assignments.ts
  function datesOf(a) {
    return a.all_dates && a.all_dates.length ? a.all_dates : [{ base: !0, due_at: a.due_at, lock_at: a.lock_at ?? null, unlock_at: a.unlock_at ?? null }];
  }
  function dueDates(a) {
    return datesOf(a).map((d) => parse(d.due_at)).filter((d) => !!d);
  }
  function isGraded(a) {
    return a.grading_type !== "not_graded" && !a.omit_from_final_grade;
  }
  function byId(list) {
    return new Map(list.map((a) => [String(a.id), a]));
  }

  // src/data/grading.ts
  function buildQueue(course, assignments, submissions) {
    let map = byId(assignments), rows = /* @__PURE__ */ new Map(), counted = /* @__PURE__ */ new Set();
    for (let s of submissions) {
      if (s.workflow_state !== "submitted" && s.workflow_state !== "pending_review" || s.excused) continue;
      let aid = String(s.assignment_id), a = map.get(aid);
      if (!a || a.grading_type === "not_graded") continue;
      let once = `${aid}:${s.user_id}`;
      if (counted.has(once)) continue;
      counted.add(once);
      let row = rows.get(aid);
      row || (row = {
        course,
        assignmentId: aid,
        name: a.name,
        count: 0,
        late: 0,
        resubmitted: 0,
        review: 0,
        oldest: null,
        dueAt: parse(a.due_at)
      }, rows.set(aid, row)), row.count++, s.late && row.late++, s.workflow_state === "pending_review" ? row.review++ : s.grade != null && s.grade_matches_current_submission === !1 && row.resubmitted++;
      let at = parse(s.submitted_at);
      at && (!row.oldest || at < row.oldest) && (row.oldest = at);
    }
    return [...rows.values()];
  }
  function queueFromCounts(course, assignments) {
    return assignments.filter((a) => (a.needs_grading_count ?? 0) > 0 && a.grading_type !== "not_graded").map((a) => ({
      course,
      assignmentId: String(a.id),
      name: a.name,
      count: a.needs_grading_count ?? 0,
      late: 0,
      resubmitted: 0,
      review: 0,
      oldest: null,
      dueAt: parse(a.due_at)
    }));
  }
  function sortQueue(rows) {
    return [...rows].sort((a, b) => a.oldest && b.oldest && a.oldest.getTime() !== b.oldest.getTime() ? a.oldest.getTime() - b.oldest.getTime() : a.oldest && !b.oldest ? -1 : !a.oldest && b.oldest ? 1 : b.count - a.count || a.name.localeCompare(b.name));
  }
  function countWaiting(assignments, submissions, cutoff) {
    let map = byId(assignments), seen = /* @__PURE__ */ new Set(), n = 0;
    for (let s of submissions) {
      if (s.workflow_state !== "submitted" && s.workflow_state !== "pending_review" || s.excused) continue;
      let a = map.get(String(s.assignment_id));
      if (!a || a.grading_type === "not_graded") continue;
      let k = `${s.assignment_id}:${s.user_id}`;
      if (seen.has(k)) continue;
      seen.add(k);
      let at = parse(s.submitted_at);
      at && at.getTime() < cutoff.getTime() && n++;
    }
    return n;
  }

  // src/data/week.ts
  function buildWeek(data, now, days = 7) {
    let first = startOfDay(now), out = Array.from({ length: days }, (_, i) => {
      let date = addDays(first, i);
      return { date, key: dayKey(date), items: [], flags: [] };
    }), index = new Map(out.map((d) => [d.key, d]));
    for (let { course, assignments } of data)
      for (let a of assignments) {
        if (!a.published) continue;
        let seenHere = /* @__PURE__ */ new Set();
        for (let d of datesOf(a)) {
          let due = parse(d.due_at);
          if (!due) continue;
          let day = index.get(dayKey(due));
          if (!day) continue;
          let { scope, forWhom } = whoFor(d), k = `${day.key}:${forWhom ?? ""}`;
          seenHere.has(k) || (seenHere.add(k), day.items.push({
            course,
            assignmentId: String(a.id),
            name: a.name,
            dueAt: due,
            points: a.points_possible,
            graded: isGraded(a) && (a.points_possible ?? 0) > 0,
            forWhom,
            scope
          }));
        }
      }
    for (let day of out)
      day.items.sort(
        (x, y) => x.dueAt.getTime() - y.dueAt.getTime() || x.course.code.localeCompare(y.course.code, "en", { numeric: !0 }) || x.name.localeCompare(y.name)
      ), day.flags = flagsFor(day.items);
    return out;
  }
  var STUDENTS_TITLE = /^\d+ students?$/i;
  function whoFor(d) {
    if (d.base) return { scope: "all", forWhom: null };
    let title = (d.title || "").trim();
    return d.set_type === "ADHOC" || d.set_type === "Group" || STUDENTS_TITLE.test(title) ? { scope: "some", forWhom: title || "some students" } : d.set_type === "CourseSection" || title ? { scope: "section", forWhom: title || null } : { scope: "all", forWhom: null };
  }
  function flagsFor(items) {
    let flags = [], byCourse = /* @__PURE__ */ new Map();
    for (let it of items) {
      if (!it.graded || it.scope === "some") continue;
      let list = byCourse.get(it.course.id) ?? [];
      list.push(it), byCourse.set(it.course.id, list);
    }
    for (let list of byCourse.values()) {
      let course = list[0].course, everyone = list.filter((i) => i.scope === "all").length;
      everyone >= 2 && flags.push({ course, forWhom: null, count: everyone });
      let sections = /* @__PURE__ */ new Map();
      for (let i of list) i.scope === "section" && i.forWhom && sections.set(i.forWhom, (sections.get(i.forWhom) ?? 0) + 1);
      for (let [name, n] of sections) everyone + n >= 2 && flags.push({ course, forWhom: name, count: everyone + n });
    }
    return flags;
  }
  var AUTO_GRADED = /* @__PURE__ */ new Set(["online_quiz", "external_tool"]);
  function needsTeacherGrading(a) {
    return !a.published || !isGraded(a) || !((a.points_possible ?? 0) > 0) ? !1 : !(a.submission_types ?? []).some((t) => AUTO_GRADED.has(t));
  }
  function buildForecast(data, now, days = 14) {
    let first = startOfDay(now), out = Array.from({ length: days }, (_, i) => {
      let date = addDays(first, i);
      return { date, key: dayKey(date), total: 0, byCourse: [] };
    }), index = new Map(out.map((d) => [d.key, d]));
    for (let { course, assignments, students } of data)
      if (students)
        for (let a of assignments) {
          if (!needsTeacherGrading(a)) continue;
          let dates = datesOf(a).filter((d) => whoFor(d).scope !== "some").map((d) => parse(d.due_at)).filter((d) => !!d);
          if (!dates.length) continue;
          let share = students / dates.length;
          for (let due of dates) {
            if (due.getTime() < now.getTime()) continue;
            let day = index.get(dayKey(due));
            if (!day) continue;
            let row = day.byCourse.find((r) => r.course.id === course.id);
            row || (row = { course, n: 0, items: [] }, day.byCourse.push(row)), row.n += share, row.items.includes(a.name) || row.items.push(a.name);
          }
        }
    for (let d of out) {
      for (let r of d.byCourse) r.n = Math.round(r.n);
      d.byCourse = d.byCourse.filter((r) => r.n > 0), d.total = d.byCourse.reduce((s, r) => s + r.n, 0);
    }
    return out;
  }

  // src/data/checkup.ts
  var RULE_INFO = [
    { rule: "not_in_module", label: "Every assignment in a module (RJ Baseline 1)", group: "baseline" },
    { rule: "missing_policy", label: "Missing policy on (RJ Baseline 2)", group: "baseline" },
    { rule: "weekly_graded", label: "A graded item every week (RJ Baseline 3)", group: "baseline" },
    { rule: "grading_waiting", label: "Grading waiting 7+ days (RJ Baseline 3)", group: "baseline" },
    { rule: "no_due_date", label: "No due date", group: "fix" },
    { rule: "unpublished_due", label: "Unpublished but due", group: "fix" },
    { rule: "locks_before_due", label: "Locks before it is due", group: "fix" },
    { rule: "opens_after_due", label: "Opens after it is due", group: "fix" },
    { rule: "outside_term", label: "Due date outside this semester", group: "fix" },
    { rule: "rubric_points", label: "Rubric total doesn't match the points", group: "fix" },
    { rule: "weights_total", label: "Group weights don't add up to 100%", group: "fix" },
    { rule: "weights_off", label: "Group weights set but turned off", group: "fix" },
    { rule: "zero_points", label: "Worth 0 points", group: "check" },
    { rule: "midnight_due", label: "Due at 12:00 AM", group: "check" },
    { rule: "weekend_due", label: "Due on a weekend", group: "check" },
    { rule: "zero_weight_group", label: "Graded work in a 0% group", group: "check" },
    { rule: "points_typo", label: "Points far above the rest of its group", group: "check" },
    { rule: "omitted", label: "Set not to count toward the final grade", group: "check" },
    { rule: "duplicate_name", label: "Two assignments with the same name", group: "check" }
  ], ALL_RULES = RULE_INFO.map((r) => r.rule), WEIGHT_TOLERANCE = 0.05, ATTENDANCE = /^roll call attendance$/i;
  function issueKey(courseId, rule, id) {
    return `${courseId}:${rule}:${id}`;
  }
  function runCheckup(course, assignments, groups, now, extra = {}) {
    let out = [], soon = addDays(now, 3).getTime(), recent = addDays(now, -14).getTime(), horizon = addDays(now, 21).getTime(), add = (rule, severity, a, detail, sortDate = Number.MAX_SAFE_INTEGER) => out.push({
      key: issueKey(course.id, rule, String(a.id)),
      course,
      rule,
      severity,
      title: a.name,
      detail,
      link: { kind: "assignment_edit", assignmentId: String(a.id) },
      sortDate
    });
    for (let a of assignments) {
      let dates = datesOf(a), due = dueDates(a), graded = isGraded(a);
      if (a.published && graded && due.length === 0 && !ATTENDANCE.test(a.name.trim()) && add("no_due_date", "fix", a, "No due date, so it won't appear in students' To Do list, calendar or RJ Tasks."), !a.published) {
        let close = due.filter((d) => d.getTime() <= soon && d.getTime() >= recent).sort((x, y) => x.getTime() - y.getTime())[0];
        if (close) {
          let past = close.getTime() < now.getTime();
          add(
            "unpublished_due",
            "fix",
            a,
            past ? `Not published, and it was due ${formatDayTime(close)}. Students can't see or submit it.` : `Not published, but it's due ${formatDayTime(close)}. Students can't see it yet.`,
            close.getTime()
          );
        }
      }
      for (let d of dates) {
        let dueAt = parse(d.due_at), lockAt = parse(d.lock_at ?? null);
        if (dueAt && lockAt && lockAt.getTime() < dueAt.getTime() && a.published) {
          let who = !d.base && d.title ? ` for ${d.title}` : "";
          add(
            "locks_before_due",
            "fix",
            a,
            `Locks ${formatDayTime(lockAt)}${who}, before it's due ${formatDayTime(dueAt)}. Students can't submit on time.`,
            dueAt.getTime()
          );
          break;
        }
      }
      if (a.published && graded && (a.grading_type === "points" || a.grading_type === "percent") && !((a.points_possible ?? 0) > 0) && add("zero_points", "check", a, "Worth 0 points, so it won't change anyone's grade."), a.published) {
        let midnight = due.filter((d) => d.getTime() > now.getTime() && d.getTime() <= horizon && isLocalMidnight(d)).sort((x, y) => x.getTime() - y.getTime())[0];
        if (midnight) {
          let nightBefore = addDays(midnight, -1);
          add(
            "midnight_due",
            "check",
            a,
            `Due at 12:00 AM on ${formatDay(midnight)}, which is the end of ${weekday(nightBefore)}. Students often read it as ${weekday(midnight)} night. If you meant ${weekday(nightBefore)} night, 11:59 PM is clearer.`,
            midnight.getTime()
          );
        }
      }
      perAssignmentExtras(course, a, now, add);
    }
    if (courseLevelExtras(course, assignments, groups, now, extra, out), course.weighted && groups.length) {
      let total = groups.reduce((s, g) => s + (g.group_weight ?? 0), 0);
      Math.abs(total - 100) > WEIGHT_TOLERANCE && out.push({
        key: issueKey(course.id, "weights_total", "course"),
        course,
        rule: "weights_total",
        severity: "fix",
        title: "Assignment group weights",
        detail: total < 100 ? `The weights add up to ${round(total)}%, not 100%. Canvas scales them up, so each group counts for more than its weight says.` : `The weights add up to ${round(total)}%, more than 100%. Canvas doesn't scale them down, so class grades can come out higher than they should.`,
        link: { kind: "assignments_index" },
        sortDate: 0
      });
      for (let g of groups) {
        if ((g.group_weight ?? 0) !== 0) continue;
        let counted = assignments.filter(
          (a) => String(a.assignment_group_id) === String(g.id) && a.published && isGraded(a) && (a.points_possible ?? 0) > 0
        );
        counted.length && out.push({
          key: issueKey(course.id, "zero_weight_group", String(g.id)),
          course,
          rule: "zero_weight_group",
          severity: "check",
          title: g.name,
          detail: `This group is weighted 0%, so its ${counted.length} graded assignment${counted.length === 1 ? "" : "s"} don't count toward the class grade.`,
          link: { kind: "assignments_index" },
          sortDate: 1
        });
      }
    }
    return out;
  }
  function sortIssues(issues) {
    let sev = (s) => s === "fix" ? 0 : 1;
    return [...issues].sort(
      (a, b) => sev(a.severity) - sev(b.severity) || a.sortDate - b.sortDate || a.course.code.localeCompare(b.course.code, "en", { numeric: !0 }) || a.title.localeCompare(b.title)
    );
  }
  function weekday(d) {
    return d.toLocaleDateString("en-US", { weekday: "long" });
  }
  function round(n) {
    return Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0$/, "");
  }
  var DAY = 864e5, SHORT = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" });
  function perAssignmentExtras(course, a, now, add) {
    if (!a.published || ATTENDANCE.test(a.name.trim())) return;
    let dates = datesOf(a), graded = isGraded(a), pts = a.points_possible ?? 0;
    if (course.termStart && course.termEnd) {
      let out = dates.filter((d) => whoFor(d).scope !== "some").map((d) => parse(d.due_at)).filter((d) => !!d).filter((d) => d.getTime() < course.termStart - DAY || d.getTime() > course.termEnd + DAY).sort((x, y) => x.getTime() - y.getTime())[0];
      out && add(
        "outside_term",
        "fix",
        a,
        `Due ${SHORT.format(out)}, outside this semester (${SHORT.format(new Date(course.termStart))} – ${SHORT.format(new Date(course.termEnd))}). Often a date left over from copying a course.`,
        out.getTime()
      );
    }
    for (let d of dates) {
      let due = parse(d.due_at), opens = parse(d.unlock_at ?? null);
      if (due && opens && opens.getTime() > due.getTime()) {
        let who = !d.base && d.title ? ` for ${d.title}` : "";
        add("opens_after_due", "fix", a, `Opens ${formatDayTime(opens)}${who}, after it's due ${formatDayTime(due)}. Students can't see it until it's already late.`, due.getTime());
        break;
      }
    }
    if (graded) {
      let horizon = addDays(now, 21).getTime();
      for (let d of dates) {
        let due = parse(d.due_at);
        if (!due || due.getTime() <= now.getTime() || due.getTime() > horizon || whoFor(d).scope === "some" || isLocalMidnight(due)) continue;
        let wd = due.getDay();
        if (wd === 0 || wd === 6) {
          add("weekend_due", "check", a, `Due ${formatDayTime(due)}, which falls on a ${due.toLocaleDateString("en-US", { weekday: "long" })}.`, due.getTime());
          break;
        }
      }
    }
    let rubric = a.rubric_settings?.points_possible;
    graded && typeof rubric == "number" && rubric > 0 && pts > 0 && Math.abs(rubric - pts) > 1e-3 && add(
      "rubric_points",
      a.use_rubric_for_grading ? "fix" : "check",
      a,
      a.use_rubric_for_grading ? `The rubric adds up to ${num(rubric)} points but the assignment is worth ${num(pts)}, and the rubric is used for grading, so scores come out wrong.` : `The rubric adds up to ${num(rubric)} points but the assignment is worth ${num(pts)}.`
    ), a.omit_from_final_grade && a.grading_type !== "not_graded" && pts > 0 && add("omitted", "check", a, `Worth ${num(pts)} points, but "Do not count this assignment towards the final grade" is checked, so it never changes anyone's grade.`);
  }
  function courseLevelExtras(course, assignments, groups, now, extra, out) {
    let push = (rule, severity, id, title, detail, link, sortDate, baseline) => out.push({ key: issueKey(course.id, rule, id), course, rule, severity, title, detail, link, sortDate, baseline }), published = assignments.filter((a) => a.published && !ATTENDANCE.test(a.name.trim())), counts = (a) => isGraded(a) && (a.points_possible ?? 0) > 0;
    !course.weighted && groups.length > 1 && groups.map((g) => g.group_weight ?? 0).reduce((x, y) => x + y, 0) > 0 && push(
      "weights_off",
      "check",
      "course",
      "Assignment group weights",
      `Your groups have weights (${groups.filter((g) => (g.group_weight ?? 0) > 0).map((g) => `${g.name} ${round(g.group_weight ?? 0)}%`).slice(0, 4).join(", ")}), but "Weight final grade based on assignment groups" is off, so Canvas grades by total points. If you meant to weight, turn it on; if these are leftovers from a copied course, click Ignore.`,
      { kind: "assignments_index" },
      0
    );
    for (let g of groups) {
      let inGroup = published.filter((a) => String(a.assignment_group_id) === String(g.id) && counts(a));
      if (inGroup.length < 4) continue;
      let sorted = inGroup.map((a) => a.points_possible ?? 0).sort((x, y) => x - y), median = sorted[Math.floor(sorted.length / 2)];
      for (let a of inGroup) {
        let p = a.points_possible ?? 0;
        median > 0 && p >= 5 * median && p >= 50 && out.push({
          key: issueKey(course.id, "points_typo", String(a.id)),
          course,
          rule: "points_typo",
          severity: "check",
          title: a.name,
          detail: `Worth ${num(p)} points; most of ${g.name} is about ${num(median)}. Worth checking for a typo.`,
          link: { kind: "assignment_edit", assignmentId: String(a.id) },
          sortDate: Number.MAX_SAFE_INTEGER
        });
      }
    }
    let byName = /* @__PURE__ */ new Map();
    for (let a of published) {
      let k = a.name.trim().toLowerCase().replace(/\s+/g, " ");
      k && byName.set(k, [...byName.get(k) ?? [], a]);
    }
    for (let list of byName.values()) {
      if (list.length < 2) continue;
      let first = [...list].sort((x, y) => Number(x.id) - Number(y.id))[0];
      push(
        "duplicate_name",
        "check",
        String(first.id),
        first.name,
        `${list.length} published assignments are called this. Students can submit to the wrong one.`,
        { kind: "assignments_index" },
        Number.MAX_SAFE_INTEGER
      );
    }
    if (Array.isArray(extra.modules)) {
      let reach = reachableFromModules(extra.modules), missing = published.filter(
        (a) => !reach.assignments.has(String(a.id)) && !(a.quiz_id && reach.quizzes.has(String(a.quiz_id))) && !(a.discussion_topic?.id && reach.discussions.has(String(a.discussion_topic.id)))
      );
      if (missing.length) {
        let names = missing.slice(0, 3).map((a) => a.name).join("; ");
        push(
          "not_in_module",
          "fix",
          idsKey(missing.map((a) => String(a.id))),
          // a new loose assignment brings it back after Ignore
          missing.length === 1 ? "1 assignment not in Modules" : `${missing.length} assignments not in Modules`,
          `${names}${missing.length > 3 ? `; and ${missing.length - 3} more` : ""}. Students can't reach ${missing.length === 1 ? "it" : "them"} from Modules. RJ Baseline 1: every assignment in a module.`,
          { kind: "modules" },
          0,
          1
        );
      }
    }
    extra.missingPolicyOn === !1 && push(
      "missing_policy",
      "fix",
      "course",
      "Missing policy is off",
      '"Automatically apply grade for missing submissions" is off. Turn it on in the Gradebook: Settings (gear) → Late Policies. RJ Baseline 2.',
      { kind: "gradebook" },
      0,
      2
    ), typeof extra.waiting7 == "number" && extra.waiting7 > 0 && push(
      "grading_waiting",
      "fix",
      dayKey(mondayOf(now)).replace(/\D/g, ""),
      // Ignore lasts for this week only
      "Grading waiting 7+ days",
      `${extra.waiting7} ${extra.waiting7 === 1 ? "submission has" : "submissions have"} waited more than 7 days to be graded. RJ Baseline 3: keep grading current.`,
      { kind: "gradebook" },
      0,
      3
    );
    let gradedDue = (a) => isGraded(a) && (a.points_possible ?? 0) > 0 && !ATTENDANCE.test(a.name.trim()) ? datesOf(a).filter((d) => whoFor(d).scope !== "some").map((d) => parse(d.due_at)).filter((d) => !!d) : [], allGraded = assignments.flatMap(gradedDue), firstGraded = allGraded.length ? Math.min(...allGraded.map((d) => d.getTime())) : null;
    if (course.termStart && course.termEnd && firstGraded !== null && now.getTime() >= course.termStart && now.getTime() < course.termEnd) {
      let monday = mondayOf(now), weeks = [];
      now.getDay() >= 1 && now.getDay() <= 4 && weeks.push({ start: monday, label: "this" });
      let nextMon = addDays(monday, 7);
      nextMon.getTime() < course.termEnd && weeks.push({ start: nextMon, label: "next" });
      for (let w of weeks) {
        let end = addDays(w.start, 7).getTime();
        if (end <= firstGraded || extra.activeWeeks && !extra.activeWeeks.has(dayKey(w.start)) || allGraded.some((d) => d.getTime() >= w.start.getTime() && d.getTime() < end)) continue;
        let range = `${formatDay(w.start)} – ${formatDay(addDays(w.start, 6))}`;
        push(
          "weekly_graded",
          w.label === "this" ? "fix" : "check",
          dayKey(w.start).replace(/\D/g, ""),
          w.label === "this" ? "Nothing graded due this week" : "Nothing graded due next week",
          `No graded assignment is due ${w.label} week (${range}). RJ Baseline 3: a graded item every week. A break week? Click Ignore.`,
          { kind: "assignments_index" },
          w.start.getTime(),
          3
        );
      }
    }
  }
  function activeWeeksOf(lists) {
    let out = /* @__PURE__ */ new Set();
    for (let list of lists)
      for (let a of list)
        for (let d of datesOf(a)) {
          let due = parse(d.due_at);
          due && whoFor(d).scope !== "some" && out.add(dayKey(mondayOf(due)));
        }
    return out;
  }
  function idsKey(ids) {
    let h2 = 2166136261;
    for (let ch of [...ids].sort().join(","))
      h2 ^= ch.charCodeAt(0), h2 = Math.imul(h2, 16777619) >>> 0;
    return String(h2);
  }
  function reachableFromModules(modules) {
    let r = { assignments: /* @__PURE__ */ new Set(), quizzes: /* @__PURE__ */ new Set(), discussions: /* @__PURE__ */ new Set() };
    for (let m of modules)
      if (m.published !== !1)
        for (let it of m.items ?? []) {
          if (it.published === !1 || it.content_id == null) continue;
          let id = String(it.content_id);
          it.type === "Assignment" ? r.assignments.add(id) : it.type === "Quiz" ? r.quizzes.add(id) : it.type === "Discussion" && r.discussions.add(id);
        }
    return r;
  }
  function mondayOf(d) {
    let day = startOfDay(d), back = (day.getDay() + 6) % 7;
    return addDays(day, -back);
  }
  function num(n) {
    return Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0+$/, "").replace(/\.$/, "");
  }

  // src/data/students.ts
  function currentPeriod(periods, now) {
    return periods.find((p) => {
      let s = parse(p.start_date), e = parse(p.end_date);
      return (!s || s <= now) && (!e || now <= e);
    }) ?? null;
  }
  function pastDueIds(assignments, period, now) {
    let start2 = parse(period?.start_date ?? null), end = parse(period?.end_date ?? null);
    return assignments.filter((a) => a.published && isGraded(a)).filter(
      (a) => dueDates(a).some((d) => d < now && (!start2 || d >= start2) && (!end || d <= end))
    ).map((a) => String(a.id));
  }
  function buildStudents(course, users, submissions, assignments, threshold) {
    let people = new Map(users.map((u) => [String(u.id), u])), map = byId(assignments), rows = /* @__PURE__ */ new Map(), seen = /* @__PURE__ */ new Set();
    for (let s of submissions) {
      if (!s.missing || s.excused) continue;
      let uid = String(s.user_id), u = people.get(uid), a = map.get(String(s.assignment_id));
      if (!u || !a) continue;
      let once = `${uid}:${a.id}`;
      if (seen.has(once)) continue;
      seen.add(once);
      let row = rows.get(uid);
      row || (row = { course, userId: uid, name: u.name, sortableName: u.sortable_name || u.name, missing: [] }, rows.set(uid, row)), row.missing.push({
        assignmentId: String(a.id),
        name: a.name,
        dueAt: parse(s.cached_due_date ?? null) ?? parse(a.due_at)
      });
    }
    return [...rows.values()].filter((r) => r.missing.length >= threshold).map((r) => ({
      ...r,
      missing: [...r.missing].sort((x, y) => (x.dueAt?.getTime() ?? 0) - (y.dueAt?.getTime() ?? 0))
    })).sort((a, b) => b.missing.length - a.missing.length || a.sortableName.localeCompare(b.sortableName));
  }
  function studentsAsText(rows) {
    let lines = [], course = "";
    for (let r of rows)
      r.course.id !== course && (lines.length && lines.push(""), course = r.course.id, lines.push(r.course.code === r.course.name ? r.course.name : `${r.course.code} · ${r.course.name}`)), lines.push(`${r.name} (${r.missing.length} missing): ${r.missing.map((m) => m.name).join("; ")}`);
    return lines.join(`
`);
  }
  function chunk(list, size) {
    let out = [];
    for (let i = 0; i < list.length; i += size) out.push(list.slice(i, i + size));
    return out;
  }

  // src/data/loader.ts
  var PARALLEL = 3, MAX_MODULE_FETCHES = 30, IDS_PER_REQUEST = 20, Loader = class {
    constructor(now = () => /* @__PURE__ */ new Date()) {
      this.now = now;
      this.memo = /* @__PURE__ */ new Map();
    }
    reset() {
      this.memo.clear();
    }
    once(key, fn) {
      let p = this.memo.get(key);
      return p || (p = fn(), this.memo.set(key, p), p.catch(() => this.memo.delete(key))), p;
    }
    rawCourses() {
      return this.once("courses", async () => {
        let { items } = await canvasGetAll(
          "/api/v1/courses?enrollment_state=active&include[]=term&per_page=100"
        );
        return items;
      });
    }
    courses(excluded = [], allClasses = !1) {
      return this.rawCourses().then((all) => teacherCourses(all, this.now(), excluded, allClasses));
    }
    assignments(cid) {
      let id = assertId(cid);
      return this.once(`a:${id}`, async () => {
        let { items } = await canvasGetAll(
          `/api/v1/courses/${id}/assignments?include[]=all_dates&per_page=100`
        );
        return items;
      });
    }
    groups(cid) {
      let id = assertId(cid);
      return this.once(`g:${id}`, async () => {
        let { items } = await canvasGetAll(
          `/api/v1/courses/${id}/assignment_groups?per_page=100`
        );
        return items;
      });
    }
    /* Active students only: the Test Student, dropped and concluded students are left out. */
    users(cid) {
      let id = assertId(cid);
      return this.once(`u:${id}`, async () => {
        let { items } = await canvasGetAll(
          `/api/v1/courses/${id}/users?enrollment_type[]=student&enrollment_state[]=active&per_page=100`
        );
        return items;
      });
    }
    activeOnly(subs, users) {
      if (!users) return subs;
      let ids = new Set(users.map((u) => String(u.id)));
      return subs.filter((s) => ids.has(String(s.user_id)));
    }
    toGradeSubmissions(cid) {
      let id = assertId(cid);
      return this.once(`s:${id}`, async () => {
        let lists = await Promise.all(
          ["submitted", "pending_review"].map(
            (state) => canvasGetAll(
              `/api/v1/courses/${id}/students/submissions?student_ids[]=all&enrollment_state=active&workflow_state=${state}&per_page=100`
            )
          )
        );
        return { subs: lists.flatMap((l) => l.items), partial: lists.some((l) => l.truncated) };
      });
    }
    async toGrade(courses) {
      let failed = [], partial = !1, rows = await mapLimit(courses, PARALLEL, async (c) => {
        let assignments;
        try {
          assignments = await this.assignments(c.id);
        } catch {
          return failed.push(c), [];
        }
        try {
          let [r, users] = await Promise.all([
            this.toGradeSubmissions(c.id),
            this.users(c.id).catch(() => null)
          ]);
          return partial ||= r.partial, buildQueue(c, assignments, this.activeOnly(r.subs, users));
        } catch {
          return queueFromCounts(c, assignments);
        }
      });
      return { value: sortQueue(rows.flat()), failed, partial };
    }
    /* Modules with their items. Canvas leaves items out of very big modules;
       those are fetched one module at a time. */
    modules(cid) {
      let id = assertId(cid);
      return this.once(`mod:${id}`, async () => {
        let { items, truncated } = await canvasGetAll(
          `/api/v1/courses/${id}/modules?include[]=items&per_page=100`
        );
        if (truncated) throw new Error("too many modules to check");
        if (items.filter((m) => !Array.isArray(m.items)).length > MAX_MODULE_FETCHES) throw new Error("too many modules to check");
        for (let m of items) {
          if (Array.isArray(m.items)) continue;
          let r = await canvasGetAll(
            `/api/v1/courses/${id}/modules/${assertId(m.id)}/items?per_page=100`
          );
          if (r.truncated) throw new Error("too many module items to check");
          m.items = r.items;
        }
        return items;
      });
    }
    /* true/false for "Automatically apply grade for missing submissions";
       a course that never saved a late policy has it off. */
    missingPolicyOn(cid) {
      let id = assertId(cid);
      return this.once(`lp:${id}`, async () => {
        try {
          return !!(await canvasGet(`/api/v1/courses/${id}/late_policy`))?.late_policy?.missing_submission_deduction_enabled;
        } catch (e) {
          if (e.status === 404) return !1;
          throw e;
        }
      });
    }
    /* Submissions (active students, graded assignments) waiting 7+ days. */
    async waiting7(c) {
      let [assignments, r, users] = await Promise.all([
        this.assignments(c.id),
        this.toGradeSubmissions(c.id),
        this.users(c.id).catch(() => null)
      ]);
      return countWaiting(assignments, this.activeOnly(r.subs, users), addDays(this.now(), -7));
    }
    /* A Baseline fact that couldn't be read stays "unknown" (null) for the
       rest of this page, instead of being asked for again on every view. */
    soft(key, fn) {
      return this.once(`soft:${key}`, () => fn().catch(() => null));
    }
    /* `allCourses`: every class shown to this teacher, so a one-class view
       still knows which weeks are breaks. */
    async checkup(courses, ignored, off = [], allCourses = courses) {
      let skip = new Set(off), failed = [], now = this.now(), lists = await Promise.all(allCourses.map((c) => this.assignments(c.id).catch(() => []))), activeWeeks = activeWeeksOf(lists), all = await mapLimit(courses, PARALLEL, async (c) => {
        try {
          let [a, g] = await Promise.all([this.assignments(c.id), this.groups(c.id)]), [modules, missingPolicyOn, waiting7] = await Promise.all([
            skip.has("not_in_module") ? null : this.soft(`mod:${c.id}`, () => this.modules(c.id)),
            skip.has("missing_policy") ? null : this.soft(`lp:${c.id}`, () => this.missingPolicyOn(c.id)),
            skip.has("grading_waiting") ? null : this.soft(`w7:${c.id}`, () => this.waiting7(c))
          ]);
          return runCheckup(c, a, g, now, { modules, missingPolicyOn, waiting7, activeWeeks }).filter((i) => !skip.has(i.rule));
        } catch {
          return failed.push(c), [];
        }
      });
      return { value: sortIssues(all.flat().filter((i) => !ignored.has(i.key))), failed, partial: !1 };
    }
    async period(cid) {
      let id = assertId(cid);
      try {
        let r = await this.once(
          `p:${id}`,
          () => canvasGet(
            `/api/v1/courses/${id}/grading_periods?per_page=100`
          )
        );
        return currentPeriod(r?.grading_periods ?? [], this.now());
      } catch {
        return null;
      }
    }
    /* Every submission Canvas flags Missing, whatever its state: Canvas's
       missing-submission policy grades missing work (state "graded") but keeps
       the Missing flag, and so does a teacher's own "Missing" mark with a 0. */
    missing(c) {
      let id = assertId(c.id);
      return this.once(`m:${id}`, async () => {
        let [assignments, period, users] = await Promise.all([
          this.assignments(id),
          this.period(id),
          this.users(id)
        ]), ids = pastDueIds(assignments, period, this.now()), submissions = [], partial = !1;
        for (let part of chunk(ids, IDS_PER_REQUEST)) {
          let q = part.map((a) => `assignment_ids[]=${assertId(a)}`).join("&"), r = await canvasGetAll(
            `/api/v1/courses/${id}/students/submissions?student_ids[]=all&enrollment_state=active&${q}&per_page=100`
          );
          partial ||= r.truncated, submissions.push(...r.items.filter((s) => s.missing && !s.excused));
        }
        return { course: c, users, assignments, submissions, partial, periodKnown: !!period };
      });
    }
    async students(courses, threshold) {
      let failed = [], partial = !1, periodKnown = !0;
      return { value: (await mapLimit(courses, PARALLEL, async (c) => {
        try {
          let m = await this.missing(c);
          return partial ||= m.partial, periodKnown &&= m.periodKnown, buildStudents(c, m.users, m.submissions, m.assignments, threshold);
        } catch {
          return failed.push(c), [];
        }
      })).flat(), failed, partial, periodKnown };
    }
    /* Grading coming in over the next 14 days (see buildForecast). */
    async forecast(courses) {
      let failed = [], data = await mapLimit(courses, PARALLEL, async (c) => {
        try {
          let [assignments, users] = await Promise.all([this.assignments(c.id), this.users(c.id)]);
          return { course: c, assignments, students: users.length };
        } catch {
          return failed.push(c), { course: c, assignments: [], students: 0 };
        }
      });
      return { value: buildForecast(data, this.now()), failed, partial: !1 };
    }
    async week(courses) {
      let failed = [], data = await mapLimit(courses, PARALLEL, async (c) => {
        try {
          return { course: c, assignments: await this.assignments(c.id) };
        } catch {
          return failed.push(c), { course: c, assignments: [] };
        }
      });
      return { value: buildWeek(data, this.now()), failed, partial: !1 };
    }
  };

  // src/lib/settings.ts
  var SECTIONS = ["grade", "checkup", "students", "week"];
  function normalizeOrder(saved) {
    let out = [];
    if (Array.isArray(saved))
      for (let x of saved) SECTIONS.includes(x) && !out.includes(x) && out.push(x);
    for (let x of SECTIONS) out.includes(x) || out.push(x);
    return out;
  }
  var DEFAULTS = {
    missingThreshold: 3,
    hideNames: !0,
    excludedCourses: [],
    buttonOnGradingPages: !1,
    allClasses: !1,
    buttonElsewhere: !0,
    sectionOrder: [...SECTIONS],
    cardHidden: [],
    cardCollapsed: !1,
    checksOff: []
  }, THRESHOLDS = [1, 2, 3, 4, 5];
  function clean(raw) {
    let r = raw && typeof raw == "object" ? raw : {};
    return {
      missingThreshold: THRESHOLDS.includes(r.missingThreshold) ? r.missingThreshold : DEFAULTS.missingThreshold,
      hideNames: typeof r.hideNames == "boolean" ? r.hideNames : DEFAULTS.hideNames,
      excludedCourses: Array.isArray(r.excludedCourses) ? r.excludedCourses.map(String).filter((s) => /^\d{1,20}$/.test(s)).slice(0, 200) : [],
      buttonOnGradingPages: typeof r.buttonOnGradingPages == "boolean" ? r.buttonOnGradingPages : DEFAULTS.buttonOnGradingPages,
      allClasses: typeof r.allClasses == "boolean" ? r.allClasses : DEFAULTS.allClasses,
      buttonElsewhere: typeof r.buttonElsewhere == "boolean" ? r.buttonElsewhere : DEFAULTS.buttonElsewhere,
      sectionOrder: normalizeOrder(r.sectionOrder),
      cardHidden: Array.isArray(r.cardHidden) ? SECTIONS.filter((x) => r.cardHidden.includes(x)) : [],
      cardCollapsed: typeof r.cardCollapsed == "boolean" ? r.cardCollapsed : !1,
      checksOff: Array.isArray(r.checksOff) ? r.checksOff.filter((x) => typeof x == "string" && /^[a-z_]{1,30}$/.test(x)).slice(0, 50) : []
    };
  }
  async function loadSettings() {
    try {
      let got = await chrome.storage.sync.get("settings");
      return clean(got.settings);
    } catch {
      return { ...DEFAULTS };
    }
  }
  async function saveSettings(s) {
    await chrome.storage.sync.set({ settings: clean(s) });
  }
  function onSettingsChanged(fn) {
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        area === "sync" && changes.settings && fn(clean(changes.settings.newValue));
      });
    } catch {
    }
  }
  var IGNORE_KEY = /^\d{1,20}:[a-z_]{1,30}:(\d{1,20}|course)$/;
  async function loadIgnored() {
    try {
      let got = await chrome.storage.local.get("ignored"), list = Array.isArray(got.ignored) ? got.ignored : [];
      return new Set(list.filter((k) => typeof k == "string" && IGNORE_KEY.test(k)));
    } catch {
      return /* @__PURE__ */ new Set();
    }
  }
  async function setIgnored(keys) {
    let list = [...keys].filter((k) => IGNORE_KEY.test(k)).slice(-2e3);
    await chrome.storage.local.set({ ignored: list });
  }
  async function saveKnownCourses(list) {
    let clean2 = list.filter((c) => /^\d{1,20}$/.test(String(c.id))).slice(0, 100).map((c) => ({ id: String(c.id), code: String(c.code).slice(0, 120), name: String(c.name).slice(0, 200) }));
    await chrome.storage.local.set({ knownCourses: clean2 });
  }

  // src/ui/styles.ts
  var CSS = `
:host { all: initial; }
* { box-sizing: border-box; }
[hidden] { display: none !important; }
.wrap {
  --bg: #ffffff; --fg: #1f2329; --muted: #5b6168; --line: #d8dbe0; --card: #f6f7f9;
  --red: #C11430; --red-text: #a3122a; --warn-bg: #fff4e5; --warn-fg: #7a4100;
  --fix-bg: #fdecef; --link: #0b5cad; --focus: #2563eb;
  font: 16px/1.5 "Segoe UI", system-ui, -apple-system, Roboto, Arial, sans-serif;
  color: var(--fg);
}
@media (prefers-color-scheme: dark) {
  .wrap {
    --bg: #15161a; --fg: #e8e9ec; --muted: #a9adb4; --line: #33363d; --card: #1d1f24;
    --red-text: #ed516a; --warn-bg: #3a2a12; --warn-fg: #ffd28a; --fix-bg: #3a1a20; --link: #8ab8ff;
  }
}
button, select { font: inherit; color: inherit; }
:focus-visible { outline: 3px solid var(--focus); outline-offset: 2px; }

.launcher {
  position: fixed; right: 20px; bottom: 20px; z-index: 2147483000;
  display: inline-flex; align-items: center; gap: 8px;
  padding: 10px 16px; border-radius: 999px; border: 0; cursor: pointer;
  background: #2a2a2a; color: #fff; font-weight: 600; font-size: 15px;
  box-shadow: 0 4px 14px rgba(0,0,0,.25); border-bottom: 3px solid var(--red);
}
.launcher:hover { background: #3a3a3a; }
.badge {
  min-width: 24px; padding: 0 7px; border-radius: 999px; background: var(--red);
  color: #fff; font-size: 14px; line-height: 24px; text-align: center;
}

.panel {
  position: fixed; top: 0; right: 0; bottom: 0; z-index: 2147483001;
  width: min(460px, 100vw); display: flex; flex-direction: column;
  background: var(--bg); color: var(--fg); border-left: 1px solid var(--line);
  box-shadow: -8px 0 24px rgba(0,0,0,.18);
}
.mast { background: #2a2a2a; color: #fff; border-bottom: 6px solid var(--red); padding: 14px 16px 12px; display: flex; align-items: center; gap: 12px; }
.mark { width: 34px; height: 34px; border-radius: 6px; background: var(--red); color: #fff; font-weight: 800; font-size: 15px; display: grid; place-items: center; letter-spacing: .02em; flex: none; }
.mast h2 { margin: 0; font-size: 18px; font-weight: 700; line-height: 1.2; }
.mast .tag { margin: 2px 0 0; color: #b8b8b8; font-size: 13px; text-transform: uppercase; letter-spacing: .12em; }
.mast .close { margin-left: auto; background: transparent; border: 1px solid #555; color: #fff; border-radius: 6px; width: 36px; height: 36px; cursor: pointer; font-size: 18px; line-height: 1; }

.scope { display: flex; align-items: center; gap: 8px; padding: 10px 16px; border-bottom: 1px solid var(--line); }
.scope label { font-size: 14px; color: var(--muted); }
.scope select { flex: 1; min-width: 0; padding: 6px 8px; border: 1px solid var(--line); border-radius: 6px; background: var(--bg); }

.tabs { display: flex; border-bottom: 1px solid var(--line); padding: 0 8px; }
.tab { flex: 1; padding: 10px 4px 8px; background: none; border: 0; border-bottom: 3px solid transparent; cursor: pointer; font-size: 15px; color: var(--muted); font-weight: 600; }
.tab[aria-selected="true"] { color: var(--fg); border-bottom-color: var(--red); }
.tab .n { font-weight: 700; }

.body { flex: 1; overflow-y: auto; padding: 12px 16px 20px; }
.summary { margin: 0 0 12px; font-size: 16px; }
.note { margin: 12px 0 0; font-size: 14px; color: var(--muted); }
.empty { padding: 24px 8px; text-align: center; color: var(--muted); }
h3 { margin: 16px 0 8px; font-size: 13px; text-transform: uppercase; letter-spacing: .08em; color: var(--muted); }
h3:first-child { margin-top: 0; }

.row { display: block; padding: 10px 12px; margin: 0 0 8px; border: 1px solid var(--line); border-radius: 8px; background: var(--card); }
.row.old { border-left: 4px solid var(--red); }
.row.fix { border-left: 4px solid var(--red); }
.row.check { border-left: 4px solid #b26b00; }
.code { display: inline-block; font-size: 13px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; color: var(--muted); }
.title { display: block; font-weight: 600; color: var(--link); text-decoration: none; overflow-wrap: anywhere; }
a.title:hover { text-decoration: underline; }
.plain { color: var(--fg); }
.meta { display: block; font-size: 14px; color: var(--muted); }
.meta b { color: var(--fg); font-weight: 600; }
.late { color: var(--red-text); font-weight: 600; }
.actions { display: flex; gap: 8px; margin-top: 8px; flex-wrap: wrap; }
.btn { display: inline-flex; align-items: center; padding: 5px 12px; border-radius: 6px; border: 1px solid var(--line); background: var(--bg); color: var(--fg); font-size: 14px; cursor: pointer; text-decoration: none; }
.btn.primary { background: #2a2a2a; color: #fff; border-color: #2a2a2a; }
@media (prefers-color-scheme: dark) { .btn.primary { background: #e8e9ec; color: #15161a; border-color: #e8e9ec; } }

.privacy { display: flex; gap: 10px; align-items: center; justify-content: space-between; padding: 10px 12px; margin: 0 0 12px; border-radius: 8px; background: var(--warn-bg); color: var(--warn-fg); font-size: 14px; }
.count { display: flex; justify-content: space-between; padding: 8px 12px; border: 1px solid var(--line); border-radius: 8px; margin: 0 0 8px; }
details.row > summary { cursor: pointer; list-style: revert; }
details.row ul { margin: 8px 0 0; padding-left: 20px; font-size: 15px; }

.day { margin: 0 0 14px; }
.day h4 { margin: 0 0 6px; font-size: 16px; }
.day h4 .muted { color: var(--muted); font-weight: 400; font-size: 14px; }
.flag { padding: 6px 10px; margin: 0 0 6px; border-radius: 6px; background: var(--warn-bg); color: var(--warn-fg); font-size: 14px; }
.item { display: flex; gap: 8px; padding: 5px 0; border-bottom: 1px solid var(--line); font-size: 15px; }
.item .time { flex: none; width: 74px; color: var(--muted); font-size: 14px; }
.item a { color: var(--link); text-decoration: none; overflow-wrap: anywhere; }
.item .code { display: block; }
.item .pts { margin-left: auto; flex: none; color: var(--muted); font-size: 14px; }

/* grading coming in */
.fc { margin: 0 0 18px; padding: 10px 12px 8px; border: 1px solid var(--line); border-radius: 8px; background: var(--card); }
.fc h3 { margin: 0 0 4px; }
.fc .summary { font-size: 15px; margin: 0 0 8px; }
.bars { list-style: none; display: grid; grid-template-columns: repeat(14, 1fr); gap: 3px; margin: 0; padding: 0; height: 132px; }
.col { display: flex; flex-direction: column; align-items: stretch; min-width: 0; }
.col.wknd .well { background: rgba(127,127,127,.12); }
.col.mon { border-left: 2px solid var(--line); padding-left: 2px; }
.tot { font-size: 12px; font-weight: 700; text-align: center; height: 16px; line-height: 16px; }
.well { flex: 1; display: flex; flex-direction: column; justify-content: flex-end; border-radius: 3px; }
.stack { display: flex; flex-direction: column-reverse; min-height: 0; border-radius: 3px; overflow: hidden; }
.seg { display: block; min-height: 2px; }
.dl { font-size: 11px; color: var(--muted); text-align: center; line-height: 16px; }
.col:first-child .dl { font-size: 9px; font-weight: 700; text-transform: uppercase; }
.c0 { background: #1d4ed8; } .c1 { background: #c2410c; } .c2 { background: #047857; }
.c3 { background: #7c3aed; } .c4 { background: #b91c1c; } .c5 { background: #0e7490; }
@media (prefers-color-scheme: dark) {
  .c0 { background: #60a5fa; } .c1 { background: #fb923c; } .c2 { background: #34d399; }
  .c3 { background: #a78bfa; } .c4 { background: #f87171; } .c5 { background: #22d3ee; }
}
.legend { display: flex; flex-wrap: wrap; gap: 4px 12px; margin: 6px 0 0; font-size: 13px; color: var(--muted); }
.legend > span { display: inline-flex; align-items: center; gap: 5px; }
.chip { width: 10px; height: 10px; border-radius: 2px; display: inline-block; }
.fc .note { margin-top: 6px; }

.foot { display: flex; align-items: center; gap: 8px; padding: 10px 16px; border-top: 1px solid var(--line); font-size: 14px; color: var(--muted); }
.foot .spacer { flex: 1; }
.linkbtn { background: none; border: 0; padding: 4px 6px; color: var(--link); cursor: pointer; font-size: 14px; text-decoration: underline; }
.sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
`, CARD_CSS = `
:host { all: initial; display: block; margin: 0 0 18px; }
* { box-sizing: border-box; }
[hidden] { display: none !important; }
.card {
  --ink: #273540; --quiet: #767676; --rule: #e8eaec; --red: #c41130;
  --link: var(--ic-link-color, #0e68b3);
  font: 14px/1.3 "Lato Extended", Lato, "Helvetica Neue", Helvetica, Arial, sans-serif;
  color: var(--ink);
}
:focus-visible { outline: 2px solid var(--link); outline-offset: 2px; border-radius: 2px; }
button { font: inherit; color: inherit; }

/* heading: same as "Coming Up  View Calendar" */
.head { display: flex; align-items: baseline; gap: 10px; padding: 0 0 6px; border-bottom: 1px solid var(--rule); }
.head h2 { margin: 0 auto 0 0; font-size: 16px; line-height: 24px; font-weight: 700; color: var(--ink); }
.open, .hide { padding: 0; background: none; border: 0; color: var(--link); font-size: 12px; line-height: 18px; cursor: pointer; }
.open:hover, .hide:hover { text-decoration: underline; }

.sec { padding: 10px 0 2px; }
.sec-head { display: flex; align-items: center; gap: 6px; width: 100%; padding: 0; background: none; border: 0; cursor: pointer; text-align: left; }
.sec-head .label { font-size: 14px; line-height: 18px; font-weight: 700; color: var(--ink); }
.sec-head:hover .label { color: var(--link); text-decoration: underline; }
.sec-head .chev { margin-left: auto; color: var(--quiet); font-size: 16px; line-height: 18px; }
/* same as Canvas's To Do count badge */
.pill { min-width: 18px; padding: 0 6px; border-radius: 9px; background: #e8eaec; color: var(--ink); font-size: 11px; line-height: 18px; text-align: center; }
.pill.red { background: var(--red); color: #fff; }

.muted, .small { margin: 3px 0 0; color: var(--quiet); font-size: 12px; line-height: 15.6px; overflow-wrap: anywhere; }
.small { display: block; }
.muted.pad { padding: 10px 0 0; margin: 0; }
.line { margin: 3px 0 0; font-size: 14px; line-height: 18.2px; }

/* assignment rows: same as a To Do row */
.list { list-style: none; margin: 0; padding: 0; }
.list li { padding: 6px 0 0; }
.list a { color: var(--link); text-decoration: none; overflow-wrap: anywhere; }
.list a:hover { text-decoration: underline; }
.more { display: block; margin: 6px 0 0; padding: 0; background: none; border: 0; color: var(--link); font-size: 12px; line-height: 15.6px; cursor: pointer; text-align: left; }
.more:hover { text-decoration: underline; }

/* the week: a tinted box for each day, so it reads at a glance */
.strip { list-style: none; display: grid; grid-template-columns: repeat(7, 1fr); gap: 3px; margin: 6px 0 0; padding: 0; }
.strip li { display: flex; flex-direction: column; align-items: center; padding: 3px 0; border-radius: 4px; background: #f3f4f5; }
.strip li.some { background: #e7eef7; }
.strip li.flag { background: #fdecef; box-shadow: inset 0 -3px 0 var(--red); }
.strip .d { color: #5b6870; font-size: 11px; line-height: 14px; }
.strip .n { font-size: 15px; font-weight: 700; line-height: 20px; color: var(--ink); }
.sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
.foot { margin: 12px 0 0; color: var(--quiet); font-size: 12px; line-height: 15.6px; }
.foot a { color: var(--link); text-decoration: none; }
.foot a:hover { text-decoration: underline; }
`;

  // src/ui/dom.ts
  var ALLOWED_ATTR = /^(class|id|role|type|title|tabindex|hidden|disabled|href|target|rel|value|selected|for|name|open|lang|aria-[a-z]+|data-[a-z-]+)$/;
  function h(tag, attrs = {}, ...children) {
    let el = document.createElement(tag);
    for (let [k, v] of Object.entries(attrs))
      if (!(v == null || v === !1)) {
        if (!ALLOWED_ATTR.test(k)) throw new Error("Refused attribute " + k);
        if (k === "href") {
          el.setAttribute("href", safeLink(String(v)));
          continue;
        }
        el.setAttribute(k, v === !0 ? "" : String(v));
      }
    return append(el, ...children), el;
  }
  function append(el, ...children) {
    for (let c of children)
      c == null || c === !1 || el.appendChild(typeof c == "string" || typeof c == "number" ? document.createTextNode(String(c)) : c);
  }
  function clear(el) {
    for (; el.firstChild; ) el.removeChild(el.firstChild);
  }
  function safeLink(href) {
    try {
      let u = new URL(href, window.location.origin);
      return u.origin === window.location.origin && (u.protocol === "https:" || u.protocol === "http:") ? u.toString() : "#";
    } catch {
      return "#";
    }
  }
  function plural(n, one, many = one + "s") {
    return `${n} ${n === 1 ? one : many}`;
  }

  // src/ui/views.ts
  var OLD_DAYS = 7;
  function codeChip(c, show) {
    return show ? h("span", { class: "code" }, c.code) : null;
  }
  function failedNote(failed, partial) {
    let parts = [];
    return failed.length && parts.push(`Couldn't load ${failed.map((c) => c.code).join(", ")}. Try Refresh, or open the class in Canvas.`), partial && parts.push("Some lists were very long, so a few items may be missing here."), parts.length ? h("p", { class: "note", role: "status" }, parts.join(" ")) : null;
  }
  function gradingView(rows, showCourse, now) {
    let box = h("div");
    if (!rows.length)
      return box.append(h("p", { class: "empty" }, "Nothing is waiting to be graded.")), box;
    let total = rows.reduce((s, r) => s + r.count, 0);
    box.append(
      h("p", { class: "summary" }, `${plural(total, "submission")} to grade in ${plural(rows.length, "assignment")}. Oldest first.`)
    );
    for (let r of rows) {
      let old = !!r.oldest && daysBetween(r.oldest, now) >= OLD_DAYS, href = canvasLink("/courses/:c/gradebook/speed_grader?assignment_id=:a", {
        c: r.course.id,
        a: r.assignmentId
      }), meta = h("span", { class: "meta" }, h("b", {}, `${r.count} to grade`));
      r.late && meta.append(" · ", h("span", { class: "late" }, `${r.late} late`)), r.resubmitted && meta.append(` · ${r.resubmitted} resubmitted`), r.review && meta.append(` · ${r.review} quiz ${r.review === 1 ? "answer" : "answers"} to review`), r.oldest && meta.append(` · oldest waiting ${waitingFor(r.oldest, now)}`), box.append(
        h(
          "div",
          { class: old ? "row old" : "row" },
          codeChip(r.course, showCourse),
          h("a", { class: "title", href }, r.name),
          meta,
          h("div", { class: "actions" }, h("a", { class: "btn primary", href }, "Open SpeedGrader"))
        )
      );
    }
    return box;
  }
  function issueHref(i) {
    switch (i.link.kind) {
      case "assignment_edit":
        return canvasLink("/courses/:c/assignments/:a/edit", { c: i.course.id, a: i.link.assignmentId });
      case "modules":
        return canvasLink("/courses/:c/modules", { c: i.course.id });
      case "gradebook":
        return canvasLink("/courses/:c/gradebook", { c: i.course.id });
      default:
        return canvasLink("/courses/:c/assignments", { c: i.course.id });
    }
  }
  var LINK_LABEL = { assignment_edit: "Edit assignment", modules: "Open Modules", gradebook: "Open Gradebook", assignments_index: "Open assignments" };
  function checkupView(issues, ignoredHere, showCourse, onIgnore, onUnignore) {
    let box = h("div"), fix = issues.filter((i) => i.severity === "fix"), check = issues.filter((i) => i.severity === "check");
    if (!issues.length)
      box.append(h("p", { class: "empty" }, "No setup problems found."));
    else {
      let bits = [];
      fix.length && bits.push(`${fix.length} to fix`), check.length && bits.push(`${check.length} worth a look`), box.append(h("p", { class: "summary" }, bits.join(", ") + "."));
    }
    let section = (title, list) => {
      if (list.length) {
        box.append(h("h3", {}, title));
        for (let i of list) {
          let ignore = h("button", { class: "btn", type: "button" }, "Ignore");
          ignore.addEventListener("click", () => onIgnore(i)), box.append(
            h(
              "div",
              { class: `row ${i.severity}`, "data-rule": i.rule },
              codeChip(i.course, showCourse),
              h("span", { class: "title plain" }, i.title),
              h("span", { class: "meta" }, i.detail),
              h(
                "div",
                { class: "actions" },
                h("a", { class: "btn primary", href: issueHref(i) }, LINK_LABEL[i.link.kind]),
                PD_HELP[i.rule] ? h("a", { class: "btn", href: canvasLink(PD_HELP[i.rule], {}), target: "_blank", rel: "noopener" }, "How to (PD)") : null,
                ignore
              )
            )
          );
        }
      }
    };
    if (section("To fix", fix), section("Worth a look", check), ignoredHere) {
      let again = h("button", { class: "linkbtn", type: "button" }, "Show them again");
      again.addEventListener("click", onUnignore), box.append(h("p", { class: "note" }, `${plural(ignoredHere, "item")} ignored. `, again));
    }
    return box.append(
      h(
        "p",
        { class: "note" },
        "Checks the RJ Baseline (everything in Modules, missing policy on, a graded item every week, grading kept current) plus setup slips: missing or out-of-semester due dates, unpublished work that is due, open/lock dates, rubric and point mismatches, group weights, duplicate names, weekend and 12:00 AM due times."
      )
    ), box;
  }
  function studentsView(opts) {
    let { rows, threshold, namesShown, showCourse } = opts, box = h("div"), sel = h("select", { "aria-label": "Minimum missing assignments" });
    for (let n of [1, 2, 3, 4, 5]) sel.append(h("option", { value: n, selected: n === threshold }, String(n)));
    if (sel.addEventListener("change", () => opts.onThreshold(Number(sel.value))), box.append(
      h("p", { class: "summary" }, "Students with at least ", sel, opts.periodKnown ? " missing this grading period." : " missing so far this course.")
    ), !rows.length)
      return box.append(h("p", { class: "empty" }, "No students at that level. Nice.")), box;
    if (!namesShown) {
      let show = h("button", { class: "btn primary", type: "button" }, "Show names");
      show.addEventListener("click", opts.onShowNames), box.append(h("div", { class: "privacy" }, h("span", {}, "Names are hidden in case your screen is shared."), show));
      let byCourse = /* @__PURE__ */ new Map();
      for (let r of rows) {
        let e = byCourse.get(r.course.id) ?? { course: r.course, n: 0 };
        e.n++, byCourse.set(r.course.id, e);
      }
      for (let { course: course2, n } of byCourse.values())
        box.append(h("div", { class: "count" }, h("span", {}, course2.code), h("b", {}, plural(n, "student"))));
      return box;
    }
    let hide = h("button", { class: "btn", type: "button" }, "Hide names");
    hide.addEventListener("click", opts.onHideNames);
    let copy = h("button", { class: "btn", type: "button" }, "Copy list");
    copy.addEventListener("click", opts.onCopy), box.append(h("div", { class: "actions" }, hide, copy));
    let course = "";
    for (let r of rows) {
      showCourse && r.course.id !== course && (course = r.course.id, box.append(h("h3", {}, r.course.code)));
      let list = h("ul");
      for (let m of r.missing)
        list.append(h("li", {}, m.name, m.dueAt ? h("span", { class: "meta" }, `Due ${formatDay(m.dueAt)}`) : null));
      box.append(
        h(
          "details",
          { class: "row" },
          h("summary", {}, h("span", { class: "plain" }, r.name), h("span", { class: "meta" }, `${r.missing.length} missing`)),
          list,
          h(
            "div",
            { class: "actions" },
            h("a", { class: "btn", href: canvasLink("/courses/:c/grades/:u", { c: r.course.id, u: r.userId }) }, "Open grades")
          )
        )
      );
    }
    return box.append(h("p", { class: "note" }, "Uses Canvas's Missing flag, so excused work and your own missing/late marks are respected.")), box;
  }
  var timeFmt2 = new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" });
  function weekView(days, showCourse, now) {
    let box = h("div"), total = days.reduce((s, d) => s + d.items.length, 0), flagged = days.filter((d) => d.flags.length).length;
    return box.append(
      h(
        "p",
        { class: "summary" },
        `${plural(total, "item")} due from your classes in the next 7 days.` + (flagged ? ` ${plural(flagged, "day")} with 2 or more graded items for the same class.` : "")
      )
    ), days.forEach((d, idx) => {
      let label = idx === 0 ? "Today" : idx === 1 ? "Tomorrow" : d.date.toLocaleDateString("en-US", { weekday: "long" }), day = h(
        "div",
        { class: "day" },
        h("h4", {}, label, " ", h("span", { class: "muted" }, `${formatDay(d.date)} · ${plural(d.items.length, "item")}`))
      );
      for (let f of d.flags)
        day.append(
          h(
            "div",
            { class: "flag" },
            `${f.course.code}${f.forWhom ? ` · ${f.forWhom}` : ""}: ${f.count} graded items due this day`
          )
        );
      for (let it of d.items)
        day.append(
          h(
            "div",
            { class: "item" },
            h("span", { class: "time" }, timeFmt2.format(it.dueAt)),
            h(
              "span",
              {},
              showCourse ? h("span", { class: "code" }, it.course.code) : null,
              h("a", { href: canvasLink("/courses/:c/assignments/:a", { c: it.course.id, a: it.assignmentId }) }, it.name),
              it.forWhom ? h("span", { class: "meta" }, it.forWhom) : null
            ),
            it.points != null && it.points > 0 ? h("span", { class: "pts" }, `${it.points} pts`) : null
          )
        );
      box.append(day);
    }), box.append(
      h(
        "p",
        { class: "note" },
        `Shows your classes only. Canvas doesn't let teachers see what students have due in other classes. Updated ${formatDayTime(now)}.`
      )
    ), box;
  }
  var SHORT_DAY = new Intl.DateTimeFormat("en-US", { weekday: "short", month: "short", day: "numeric" }), LETTER = new Intl.DateTimeFormat("en-US", { weekday: "narrow" });
  function forecastView(days, courses, waitingNow) {
    let box = h("section", { class: "fc", "aria-labelledby": "rjtt-fc-title" });
    box.append(h("h3", { id: "rjtt-fc-title" }, "Grading coming in · next 2 weeks"));
    let total = days.reduce((s, d) => s + d.total, 0), max = Math.max(1, ...days.map((d) => d.total)), busiest = days.reduce((b, d) => d.total > b.total ? d : b, days[0]), bits = [total ? `About ${plural(total, "submission")} due from students in the next 14 days.` : "Nothing that needs your grading is due in the next 14 days."];
    total && bits.push(`Busiest: ${SHORT_DAY.format(busiest.date)} (about ${busiest.total}).`), waitingNow !== null && bits.push(`Waiting now: ${waitingNow}.`), box.append(h("p", { class: "summary" }, bits.join(" ")));
    let color = new Map(courses.map((c, i) => [c.id, i % 6])), bars = h("ol", { class: "bars", "aria-label": "Submissions due each day" });
    days.forEach((d, i) => {
      let wd = d.date.getDay(), parts = d.byCourse.map((r) => `${r.course.code} ${r.n}`).join(", "), col = h(
        "li",
        { class: `col${wd === 0 || wd === 6 ? " wknd" : ""}${wd === 1 && i > 0 ? " mon" : ""}`, title: `${SHORT_DAY.format(d.date)}: about ${d.total}${parts ? ` (${parts})` : ""}` },
        h("span", { class: "tot", "aria-hidden": "true" }, d.total ? String(d.total) : "")
      ), stack = h("div", { class: "stack", "aria-hidden": "true" });
      stack.style.height = `${Math.round(d.total / max * 100)}%`;
      for (let r of d.byCourse) {
        let seg = h("span", { class: `seg c${color.get(r.course.id) ?? 0}` });
        seg.style.flexGrow = String(r.n), stack.append(seg);
      }
      col.append(
        h("div", { class: "well" }, stack),
        h("span", { class: "dl", "aria-hidden": "true" }, i === 0 ? "Today" : LETTER.format(d.date)),
        h("span", { class: "sr" }, `${i === 0 ? "Today" : SHORT_DAY.format(d.date)}: about ${plural(d.total, "submission")}${parts ? `: ${parts}` : ""}`)
      ), bars.append(col);
    }), box.append(bars);
    let shown = courses.filter((c) => days.some((d) => d.byCourse.some((r) => r.course.id === c.id)));
    if (shown.length > 1) {
      let legend = h("p", { class: "legend" });
      for (let c of shown) legend.append(h("span", {}, h("span", { class: `chip c${color.get(c.id) ?? 0}`, "aria-hidden": "true" }), c.code));
      box.append(legend);
    }
    return box.append(
      h("p", { class: "note" }, "Estimated from due dates and class size. Leaves out quizzes Canvas grades for you and one-student extensions. Week starts are marked; weekends are shaded.")
    ), box;
  }

  // src/ui/panel.ts
  var TAB_LABELS = {
    grade: "To grade",
    checkup: "Check-up",
    students: "Students",
    week: "Week"
  }, Panel = class {
    constructor(opts) {
      this.opts = opts;
      this.panel = null;
      this.tabButtons = /* @__PURE__ */ new Map();
      this.counts = /* @__PURE__ */ new Map();
      this.scope = "all";
      this.tab = "grade";
      this.namesShown = !1;
      this.courses = [];
      this.lastStudents = [];
      this.renderToken = 0;
      /* the all-classes To grade total, whenever the panel works it out */
      this.onGradeTotal = null;
      this.now = opts.now ?? (() => /* @__PURE__ */ new Date()), this.loader = opts.loader ?? new Loader(this.now), this.host = document.createElement("div"), this.host.setAttribute("data-rjtt", ""), this.root = this.host.attachShadow({ mode: "closed" }), this.applyStyles(), this.wrap = h("div", { class: "wrap" }), this.root.appendChild(this.wrap), this.badge = h("span", { class: "badge", hidden: !0 }), this.launcher = h(
        "button",
        { class: "launcher", type: "button", "aria-haspopup": "dialog", "aria-expanded": "false" },
        "My Classes",
        this.badge
      ), this.launcher.hidden = !opts.showButton, this.launcher.addEventListener("click", () => this.toggle()), this.wrap.appendChild(this.launcher), document.addEventListener("keydown", (e) => {
        if (e.key !== "Escape" || !this.isOpen()) return;
        let inPanel = e.composedPath().includes(this.host), idle = document.activeElement === document.body || document.activeElement === null;
        !inPanel && !idle || (e.stopPropagation(), this.close());
      }, !0);
    }
    applyStyles() {
      try {
        let sheet = new CSSStyleSheet();
        sheet.replaceSync(CSS), this.root.adoptedStyleSheets = [sheet];
      } catch {
        let style = document.createElement("style");
        style.textContent = CSS, this.root.appendChild(style);
      }
    }
    setBadge(n) {
      n && n > 0 ? (this.badge.textContent = n > 99 ? "99+" : String(n), this.badge.hidden = !1, this.launcher.setAttribute("aria-label", `My Classes, ${plural(n, "submission")} to grade`)) : (this.badge.hidden = !0, this.launcher.setAttribute("aria-label", "My Classes"));
    }
    /* The floating button: shown only where there's no sidebar card in view. */
    setLauncherVisible(v) {
      this.opts.showButton = v, this.isOpen() || (this.launcher.hidden = !v);
    }
    updateSettings(s) {
      let prev = this.opts.settings;
      if (this.opts.settings = s, s.hideNames || (this.namesShown = !0), !this.isOpen()) return;
      this.tabBar && prev.sectionOrder.join(",") !== s.sectionOrder.join(",") && this.buildTabs(), prev.excludedCourses.join(",") !== s.excludedCourses.join(",") || prev.allClasses !== s.allClasses ? this.loadCourses() : (prev.missingThreshold !== s.missingThreshold || prev.hideNames !== s.hideNames || prev.checksOff.join(",") !== s.checksOff.join(",")) && this.renderTab();
    }
    isOpen() {
      return !!this.panel && !this.panel.hidden;
    }
    toggle() {
      this.isOpen() ? this.close() : this.openPanel();
    }
    close() {
      this.panel && (this.panel.hidden = !0, this.launcher.hidden = !this.opts.showButton, this.launcher.setAttribute("aria-expanded", "false"), this.namesShown = !this.opts.settings.hideNames, this.launcher.hidden ? this.opts.onClosed?.() : this.launcher.focus());
    }
    /* Open at a given view, e.g. from a sidebar card section. scope is 'all'
       or a course id; omitted keeps the current choice. */
    async openAt(tab, scope) {
      this.panel || this.build(), scope && (this.scope = scope), this.select(tab, !1), await this.openPanel();
    }
    async openPanel() {
      this.panel || this.build(), this.panel.hidden = !1, this.launcher.hidden = !0, this.launcher.setAttribute("aria-expanded", "true"), this.namesShown = this.namesShown || !this.opts.settings.hideNames, this.panel.querySelector("h2").focus(), await this.loadCourses();
    }
    build() {
      let close = h("button", { class: "close", type: "button", "aria-label": "Close" }, "✕");
      close.addEventListener("click", () => this.close());
      let tabs = h("div", { class: "tabs", role: "tablist", "aria-label": "Views" });
      this.tabBar = tabs, this.buildTabs(), this.status = h("span", { role: "status", "aria-live": "polite" });
      let refresh = h("button", { class: "linkbtn", type: "button" }, "Refresh");
      refresh.addEventListener("click", () => {
        this.loader.reset(), this.loadCourses(), this.opts.onDataChanged?.();
      });
      let settings = h("button", { class: "linkbtn", type: "button" }, "Settings");
      settings.addEventListener("click", () => this.opts.openSettings());
      let pd = h("a", { class: "linkbtn", href: canvasLink(PD_COURSE_PATH, {}), target: "_blank", rel: "noopener", title: "Regis Jesuit Professional Development in Canvas" }, "Questions?");
      this.foot = h("div", { class: "foot" }, this.status, h("span", { class: "spacer" }), pd, refresh, settings), this.body = h("div", { class: "body", id: "rjtt-body", role: "tabpanel", tabindex: "-1" }), this.panel = h(
        "section",
        { class: "panel", role: "dialog", "aria-modal": "false", "aria-labelledby": "rjtt-title" },
        h(
          "div",
          { class: "mast" },
          h("div", { class: "mark", "aria-hidden": "true" }, "RJ"),
          h("div", {}, h("h2", { id: "rjtt-title", tabindex: "-1" }, PRODUCT_NAME), h("p", { class: "tag" }, "Grading · Check-up · Students · Week")),
          close
        ),
        h("div", { class: "scope" }, h("label", { for: "rjtt-scope" }, "Show"), h("select", { id: "rjtt-scope" })),
        tabs,
        this.body,
        this.foot
      ), this.panel.hidden = !0;
      let sel = this.panel.querySelector("select");
      sel.addEventListener("change", () => {
        this.scope = sel.value, this.renderTab();
      }), this.wrap.appendChild(this.panel), this.select(this.tab, !1);
    }
    /* Tabs follow the order chosen in Settings. */
    buildTabs() {
      let order = this.opts.settings.sectionOrder;
      clear(this.tabBar), this.tabButtons.clear();
      for (let id of order) {
        let b = h("button", { class: "tab", type: "button", role: "tab", id: `rjtt-tab-${id}`, "aria-selected": String(id === this.tab), "aria-controls": "rjtt-body", "data-tab": id }, TAB_LABELS[id]);
        b.tabIndex = id === this.tab ? 0 : -1, b.addEventListener("click", () => this.select(id)), b.addEventListener("keydown", (e) => {
          let tabs = this.opts.settings.sectionOrder, i = tabs.indexOf(id);
          if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
            let next = tabs[(i + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length];
            this.select(next), this.tabButtons.get(next).focus(), e.preventDefault();
          }
        }), this.tabButtons.set(id, b), this.tabBar.append(b);
        let n = this.counts.get(id);
        n !== void 0 && this.setCount(id, n);
      }
    }
    select(tab, render = !0) {
      this.tab = tab;
      for (let [id, b] of this.tabButtons)
        b.setAttribute("aria-selected", String(id === tab)), b.tabIndex = id === tab ? 0 : -1;
      this.body.setAttribute("aria-labelledby", `rjtt-tab-${tab}`), render && this.renderTab();
    }
    setStatus(text) {
      this.status.textContent = text;
    }
    async loadCourses() {
      clear(this.body), this.body.append(h("p", { class: "empty" }, "Loading your classes…")), this.setStatus("Loading…");
      try {
        let all = this.opts.settings.allClasses;
        this.courses = await this.loader.courses(this.opts.settings.excludedCourses, all), this.loader.courses([], all).then((all2) => saveKnownCourses(all2)).catch(() => {
        });
      } catch {
        clear(this.body), this.body.append(h("p", { class: "empty" }, "Couldn't reach Canvas. Check that you're signed in, then click Refresh.")), this.setStatus("");
        return;
      }
      let sel = this.panel.querySelector("select");
      clear(sel), sel.append(h("option", { value: "all" }, `All my classes (${this.courses.length})`));
      for (let c of this.courses) sel.append(h("option", { value: c.id }, c.code === c.name ? c.name : `${c.code} · ${c.name}`));
      let cur = this.opts.currentCourseId;
      this.scope === "all" && cur && this.courses.some((c) => c.id === cur) && (this.scope = cur), this.scope !== "all" && !this.courses.some((c) => c.id === this.scope) && (this.scope = "all"), sel.value = this.scope, this.renderTab();
    }
    inScope() {
      return this.scope === "all" ? this.courses : this.courses.filter((c) => c.id === this.scope);
    }
    async renderTab() {
      if (!this.panel) return;
      let token = ++this.renderToken, courses = this.inScope(), showCourse = this.scope === "all";
      if (clear(this.body), !this.courses.length) {
        this.body.append(
          h("p", { class: "empty" }, this.opts.settings.allClasses ? "You aren't listed as the teacher of any current Canvas classes." : "You aren't listed as the teacher of any classes this semester."),
          h("p", { class: "note" }, "If that seems wrong, check Settings for classes you turned off.")
        ), this.setStatus("");
        return;
      }
      this.body.append(h("p", { class: "empty" }, "Loading…")), this.setStatus("Loading…");
      let now = this.now(), content, note = null;
      try {
        if (this.tab === "grade") {
          let r = await this.loader.toGrade(courses);
          content = gradingView(r.value, showCourse, now), note = failedNote(r.failed, r.partial);
          let total = r.value.reduce((s, x) => s + x.count, 0);
          this.setCount("grade", total), this.scope === "all" && token === this.renderToken && this.onGradeTotal?.(total);
        } else if (this.tab === "checkup") {
          let ignored = await loadIgnored(), r = await this.loader.checkup(courses, ignored, this.opts.settings.checksOff, this.courses), ids = new Set(courses.map((c) => c.id)), ignoredHere = [...ignored].filter((k) => ids.has(k.split(":")[0])).length;
          content = checkupView(r.value, ignoredHere, showCourse, (i) => this.ignore(i), () => this.unignore(courses)), note = failedNote(r.failed, r.partial), this.setCount("checkup", r.value.filter((i) => i.severity === "fix").length);
        } else if (this.tab === "students") {
          let r = await this.loader.students(courses, this.opts.settings.missingThreshold);
          this.lastStudents = r.value, content = studentsView({
            rows: r.value,
            courses,
            threshold: this.opts.settings.missingThreshold,
            periodKnown: r.periodKnown,
            namesShown: this.namesShown,
            showCourse,
            onShowNames: () => {
              this.namesShown = !0, this.renderTab();
            },
            onHideNames: () => {
              this.namesShown = !1, this.renderTab();
            },
            onCopy: () => this.copyStudents(),
            onThreshold: (n) => {
              this.opts.settings = { ...this.opts.settings, missingThreshold: n }, saveSettings(this.opts.settings).catch(() => {
              }), this.renderTab();
            }
          }), note = failedNote(r.failed, r.partial);
        } else {
          let [r, f, g] = await Promise.all([
            this.loader.week(courses),
            this.loader.forecast(courses).catch(() => null),
            this.loader.toGrade(courses).catch(() => null)
          ]);
          content = h("div"), f && content.append(forecastView(f.value, courses, g ? g.value.reduce((s, x) => s + x.count, 0) : null)), content.append(weekView(r.value, showCourse, now)), note = failedNote(r.failed, r.partial);
        }
      } catch {
        content = h("p", { class: "empty" }, "Couldn't load this from Canvas. Click Refresh to try again.");
      }
      token === this.renderToken && (clear(this.body), append(this.body, content, note), this.setStatus(`Updated ${formatDayTime(now).split(", ").pop()}`));
    }
    setCount(tab, n) {
      this.counts.set(tab, n);
      let b = this.tabButtons.get(tab);
      if (!b) return;
      let label = TAB_LABELS[tab];
      clear(b), append(b, label, n ? h("span", { class: "n" }, ` ${n}`) : null);
    }
    async ignore(i) {
      let set = await loadIgnored();
      set.add(i.key), await setIgnored(set).catch(() => {
      }), this.renderTab(), this.opts.onDataChanged?.();
    }
    async unignore(courses) {
      let ids = new Set(courses.map((c) => c.id)), set = await loadIgnored();
      for (let k of [...set]) ids.has(k.split(":")[0]) && set.delete(k);
      await setIgnored(set).catch(() => {
      }), this.renderTab(), this.opts.onDataChanged?.();
    }
    async copyStudents() {
      try {
        await navigator.clipboard.writeText(studentsAsText(this.lastStudents)), this.setStatus("List copied");
      } catch {
        this.setStatus("Couldn't copy. Select the names instead.");
      }
    }
  };

  // src/ui/card.ts
  var TOP_ROWS = 3, CACHE_PREFIX = "rjtt-card-v1:", CACHE_TTL_MS = 300 * 1e3, DAY_LETTER = new Intl.DateTimeFormat("en-US", { weekday: "narrow" }), DAY_NAME = new Intl.DateTimeFormat("en-US", { weekday: "long", month: "short", day: "numeric" }), LABELS = { grade: "To grade", checkup: "Check-up", students: "Students", week: "Week" }, SUMMARY_KEY = { grade: "grade", checkup: "checkup", students: "students", week: "week" };
  function summarizeGrade(rows) {
    return {
      total: rows.reduce((n, r) => n + r.count, 0),
      assignments: rows.length,
      rows: rows.slice(0, TOP_ROWS).map((r) => ({
        courseId: r.course.id,
        code: r.course.code,
        assignmentId: r.assignmentId,
        name: r.name,
        count: r.count,
        oldest: r.oldest ? r.oldest.getTime() : null
      }))
    };
  }
  function summarizeWeek(days) {
    return {
      total: days.reduce((n, d) => n + d.items.length, 0),
      days: days.map((d) => ({ at: d.date.getTime(), n: d.items.length, flagged: d.flags.length > 0 }))
    };
  }
  function readCache(key, want) {
    try {
      let raw = window.sessionStorage.getItem(CACHE_PREFIX + key);
      if (!raw) return null;
      let v = JSON.parse(raw);
      if (typeof v.t != "number" || Date.now() - v.t > CACHE_TTL_MS || !v.s || typeof v.s != "object") return null;
      let s = v.s;
      return want.every((t) => !!s[SUMMARY_KEY[t]]) ? s : null;
    } catch {
      return null;
    }
  }
  function writeCache(key, s) {
    try {
      window.sessionStorage.setItem(CACHE_PREFIX + key, JSON.stringify({ t: Date.now(), s }));
    } catch {
    }
  }
  function clearCardCache() {
    try {
      for (let i = window.sessionStorage.length - 1; i >= 0; i--) {
        let k = window.sessionStorage.key(i);
        k && k.startsWith(CACHE_PREFIX) && window.sessionStorage.removeItem(k);
      }
    } catch {
    }
  }
  var SidebarCard = class {
    constructor(opts) {
      this.opts = opts;
      this.sections = /* @__PURE__ */ new Map();
      this.token = 0;
      this.lastTab = null;
      this.lastFocus = null;
      this.lostAt = 0;
      this.now = opts.now ?? (() => /* @__PURE__ */ new Date()), this.host = document.createElement("div"), this.host.setAttribute("data-rjtt-card", ""), this.root = this.host.attachShadow({ mode: "closed" });
      try {
        let sheet = new CSSStyleSheet();
        sheet.replaceSync(CARD_CSS), this.root.adoptedStyleSheets = [sheet];
      } catch {
        let style = document.createElement("style");
        style.textContent = CARD_CSS, this.root.appendChild(style);
      }
      this.wrap = h("section", { class: "card", "aria-labelledby": "rjtt-card-title" }), this.root.appendChild(this.wrap), this.wrap.addEventListener("focusin", (e) => {
        let t = e.target;
        this.lastFocus = { cls: t.className, sec: t.closest(".sec")?.getAttribute("data-sec") ?? null };
      }), this.wrap.addEventListener("focusout", () => this.lostAt = Date.now());
    }
    /* After the card is moved back into the sidebar: if it had focus a moment
       ago and nothing else has it now, give it back. */
    refocusAfterMove() {
      let idle = document.activeElement === document.body || document.activeElement === null;
      if (!this.lastFocus || !idle || Date.now() - this.lostAt > 1e3) return;
      let f = this.lastFocus;
      (f.sec ? this.sections.get(f.sec)?.querySelector(".sec-head") : this.wrap.querySelector(f.cls === "hide" ? ".hide" : ".open"))?.focus();
    }
    cacheKey() {
      return this.cacheKeyFor(this.opts.settings);
    }
    cacheKeyFor(s) {
      return [
        this.opts.courseId ?? "all",
        s.allClasses ? "all" : "sem",
        s.excludedCourses.slice().sort().join(","),
        s.missingThreshold,
        s.cardHidden.join(","),
        s.checksOff.slice().sort().join(",")
      ].join("|");
    }
    /* What the card's contents depend on. */
    layoutKey(s) {
      return [this.cacheKeyFor(s), s.sectionOrder.join(","), s.cardCollapsed].join("#");
    }
    /* Always keeps the latest settings (so Hide can't save a stale copy);
       reloads only when something the card shows has changed. */
    updateSettings(s) {
      let changed = this.layoutKey(s) !== this.layoutKey(this.opts.settings);
      this.opts.settings = s, changed && this.load();
    }
    /* After Refresh or Ignore in the panel: drop the cached summary and reload. */
    refresh() {
      clearCardCache(), this.load();
    }
    /* Focus the section heading that opened the panel (for when it closes). */
    focusLast() {
      let tab = this.lastTab ?? this.shown()[0] ?? "grade";
      (this.sections.get(tab)?.querySelector(".sec-head") ?? this.wrap.querySelector(".open"))?.focus();
    }
    open(tab) {
      this.lastTab = tab, this.opts.onOpen(tab);
    }
    async load() {
      let token = ++this.token, live = () => token === this.token, scoped = this.opts.courseId !== null, key = this.cacheKey(), summary = {}, want = this.shown();
      if (this.buildShell(scoped, this.opts.settings.cardCollapsed ? [] : want), this.opts.settings.cardCollapsed) return;
      if (!want.length) {
        this.message("All sections are turned off in RJ Tasks settings. Click Open for the full view.");
        return;
      }
      let cached = readCache(key, want);
      if (cached) {
        this.render(cached, scoped), cached.grade && this.opts.onGradeCount?.(cached.grade.total);
        return;
      }
      let courses, all;
      try {
        all = await this.opts.loader.courses(this.opts.settings.excludedCourses, this.opts.settings.allClasses), courses = scoped ? all.filter((c) => c.id === this.opts.courseId) : all;
      } catch {
        live() && this.message("Couldn't reach Canvas. Refresh the page to try again.");
        return;
      }
      if (!live()) return;
      if (!courses.length) {
        this.message(
          scoped ? "This class is turned off in RJ Tasks settings." : "No classes this semester. Classes you turned off in Settings are left out."
        );
        return;
      }
      let L = this.opts.loader, s = this.opts.settings, steps = [
        ["grade", async () => {
          let r = await L.toGrade(courses);
          summary.grade = summarizeGrade(r.value), live() && this.opts.onGradeCount?.(summary.grade.total);
        }],
        ["week", async () => {
          let r = await L.week(courses);
          summary.week = summarizeWeek(r.value);
        }],
        ["checkup", async () => {
          let r = await L.checkup(courses, await loadIgnored(), s.checksOff, all), fix = r.value.filter((i) => i.severity === "fix");
          summary.checkup = {
            fix: fix.length,
            check: r.value.length - fix.length,
            top: fix.slice(0, 2).map((i) => ({ code: i.course.code, title: i.title }))
          };
        }],
        ["students", async () => {
          let r = await L.students(courses, s.missingThreshold);
          summary.students = { n: r.value.length, periodKnown: r.periodKnown };
        }]
      ];
      for (let [tab, run] of steps)
        if (want.includes(tab)) {
          try {
            await run();
          } catch {
            summary[SUMMARY_KEY[tab]] = null;
          }
          if (!live()) return;
          this.render(summary, scoped);
        }
      want.every((t) => !!summary[SUMMARY_KEY[t]]) && writeCache(key, summary);
    }
    /* Visible sections, in the order chosen in Settings. */
    shown() {
      let s = this.opts.settings;
      return s.sectionOrder.filter((t) => !s.cardHidden.includes(t));
    }
    buildShell(scoped, want) {
      let had = this.root.activeElement?.className;
      clear(this.wrap), this.sections.clear();
      let open = h("button", { class: "open", type: "button" }, "Open");
      open.addEventListener("click", () => this.open(this.shown()[0] ?? this.opts.settings.sectionOrder[0]));
      let collapsed = this.opts.settings.cardCollapsed, hide = h(
        "button",
        { class: "hide", type: "button", "aria-expanded": String(!collapsed), "aria-label": collapsed ? "Show the My Classes summary" : "Hide the My Classes summary" },
        collapsed ? "Show" : "Hide"
      );
      hide.addEventListener("click", async () => {
        let next = { ...await loadSettings(), cardCollapsed: !collapsed };
        this.opts.settings = next, await this.load(), this.wrap.querySelector(".hide")?.focus(), saveSettings(next).catch(() => {
        });
      }), this.wrap.append(
        h(
          "div",
          { class: "head" },
          h("h2", { id: "rjtt-card-title" }, scoped ? "This class" : "My Classes"),
          hide,
          open
        )
      ), had === "hide" ? hide.focus() : had === "open" && open.focus();
      for (let tab of want) {
        let sec = h("div", { class: "sec", "data-sec": tab }, this.sectionHead(tab, null), h("p", { class: "muted" }, "Loading…"));
        this.sections.set(tab, sec), this.wrap.append(sec);
      }
      want.length && this.wrap.append(
        h(
          "p",
          { class: "foot" },
          "Questions? ",
          h("a", { href: canvasLink(PD_COURSE_PATH, {}), target: "_blank", rel: "noopener" }, "Canvas PD course")
        )
      );
    }
    message(msg) {
      let head = this.wrap.querySelector(".head");
      clear(this.wrap), this.sections.clear(), head && this.wrap.append(head), this.wrap.append(h("p", { class: "muted pad" }, msg));
    }
    /* The whole heading is a button that opens the full panel at that view. */
    sectionHead(tab, n) {
      let label = LABELS[tab], b = h(
        "button",
        { class: "sec-head", type: "button", "aria-label": `${label}${n ? `, ${n}` : ""}: open in the full view` },
        h("span", { class: "label" }, label),
        n ? h("span", { class: tab === "checkup" || tab === "grade" ? "pill red" : "pill" }, n > 99 ? "99+" : String(n)) : null,
        h("span", { class: "chev", "aria-hidden": "true" }, "›")
      );
      return b.addEventListener("click", () => this.open(tab)), b;
    }
    /* Fill whichever sections have data; leave the rest saying Loading. Keeps
       keyboard focus on the same section heading if it was there. */
    render(s, scoped) {
      let focused = this.root.activeElement?.closest(".sec")?.getAttribute("data-sec"), now = this.now();
      s.grade !== void 0 && this.fill("grade", s.grade ? s.grade.total : null, s.grade ? this.gradeBody(s.grade, !scoped, now) : this.failed()), s.checkup !== void 0 && this.fill("checkup", s.checkup ? s.checkup.fix : null, s.checkup ? this.checkupBody(s.checkup, !scoped) : this.failed()), s.students !== void 0 && this.fill("students", s.students ? s.students.n : null, s.students ? this.studentsBody(s.students) : this.failed()), s.week !== void 0 && this.fill("week", null, s.week ? this.weekStrip(s.week) : this.failed()), focused && this.sections.get(focused)?.querySelector(".sec-head")?.focus();
    }
    fill(tab, n, body) {
      let sec = this.sections.get(tab);
      sec && (clear(sec), append(sec, this.sectionHead(tab, n), body));
    }
    failed() {
      return h("p", { class: "muted" }, "Couldn't load. Refresh the page to try again.");
    }
    gradeBody(g, showCourse, now) {
      let box = h("div");
      if (!g.rows.length)
        return box.append(h("p", { class: "muted" }, "Nothing waiting. Nice.")), box;
      let list = h("ul", { class: "list" });
      for (let r of g.rows) {
        let href = canvasLink("/courses/:c/gradebook/speed_grader?assignment_id=:a", { c: r.courseId, a: r.assignmentId });
        list.append(
          h(
            "li",
            {},
            h("a", { href }, r.name),
            h("span", { class: "small" }, `${showCourse ? `${r.code} · ` : ""}${r.count} to grade${r.oldest ? ` · waiting ${waitingFor(new Date(r.oldest), now)}` : ""}`)
          )
        );
      }
      if (box.append(list), g.assignments > g.rows.length) {
        let more = h("button", { class: "more", type: "button" }, `${plural(g.assignments - g.rows.length, "more assignment")} (${plural(g.total, "submission")} in all)`);
        more.addEventListener("click", () => this.open("grade")), box.append(more);
      }
      return box;
    }
    checkupBody(c, showCourse) {
      let body = h("div");
      if (!c.fix && !c.check)
        return body.append(h("p", { class: "muted" }, "No setup problems found.")), body;
      body.append(h("p", { class: "line" }, [c.fix ? `${c.fix} to fix` : "", c.check ? `${c.check} worth a look` : ""].filter(Boolean).join(" · ")));
      for (let i of c.top) body.append(h("p", { class: "small" }, showCourse ? `${i.code}: ` : "", i.title));
      return body;
    }
    studentsBody(st) {
      let t = this.opts.settings.missingThreshold, when = st.periodKnown ? "this grading period" : "so far";
      return h(
        "p",
        { class: st.n ? "line" : "muted" },
        st.n ? `${plural(st.n, "student")} with ${t}+ missing ${when}` : `No students with ${t}+ missing ${when}.`
      );
    }
    weekStrip(w) {
      let box = h("div"), strip = h("ol", { class: "strip", "aria-label": "Items due each of the next 7 days" });
      w.days.forEach((d, i) => {
        let date = new Date(d.at), name = i === 0 ? "Today" : DAY_NAME.format(date);
        strip.append(
          h(
            "li",
            {
              class: d.flagged ? "flag" : d.n ? "some" : "",
              title: `${name}: ${plural(d.n, "item")}${d.flagged ? ", 2+ graded items for one class" : ""}`
            },
            h("span", { class: "d", "aria-hidden": "true" }, i === 0 ? "Today" : DAY_LETTER.format(date)),
            h("span", { class: "n", "aria-hidden": "true" }, String(d.n)),
            h("span", { class: "sr" }, `${name}, ${plural(d.n, "item")}${d.flagged ? ", heavy day" : ""}`)
          )
        );
      }), box.append(strip);
      let heavy = w.days.filter((d) => d.flagged).length;
      return box.append(h("p", { class: "small" }, `${plural(w.total, "item")} due in the next 7 days${heavy ? ` · ${plural(heavy, "heavy day")}` : ""}`)), box;
    }
  };
  function moveTodoUp(doc) {
    let box = doc.querySelector("#right-side > #course_show_secondary"), head = box?.querySelector(":scope > .todo-list-header"), list = box?.querySelector(":scope > .to-do-list");
    !box || !head || !list || (box.parentElement.insertBefore(head, box), box.parentElement.insertBefore(list, box));
  }
  function cardSlot(doc, kind) {
    let side = doc.querySelector("#right-side");
    if (!side) return null;
    if (kind === "course") {
      let todo = side.querySelector(":scope > .todo-list-header");
      if (todo) return { parent: side, before: todo };
      let buttons = side.querySelector(":scope > #course_show_secondary");
      if (buttons) return { parent: side, before: buttons };
    } else {
      let todo = side.querySelector(":scope > .todo-list-header");
      if (todo) return { parent: side, before: todo };
      let logo = side.querySelector(":scope > .ic-sidebar-logo");
      if (logo) return { parent: side, before: logo.nextSibling };
    }
    return { parent: side, before: side.firstChild };
  }
  function inSlot(host, slot) {
    return host.parentElement === slot.parent && (slot.before === host || host.nextSibling === slot.before);
  }
  function isShown(el) {
    if (!el.isConnected) return !1;
    let r = el.getBoundingClientRect();
    return el.getClientRects().length > 0 && r.width > 0 && r.height > 0;
  }

  // src/content.ts
  var ROLE_KEY = "rjtt-teaches-v2", ROLE_TTL_MS = 3600 * 1e3, BADGE_KEY = "rjtt-badge-v2", BADGE_TTL_MS = 300 * 1e3;
  function courseIdFromPath(path) {
    let m = path.match(/^\/courses\/(\d{1,20})(?:\/|$)/);
    return m ? m[1] : null;
  }
  function isGradingPage(path) {
    return /^\/courses\/\d{1,20}\/gradebook(?:\/|$)/.test(path);
  }
  function cardKind(path) {
    return path === "/" || path === "/dashboard" || path === "" ? "dashboard" : /^\/courses\/\d{1,20}\/?$/.test(path) ? "course" : null;
  }
  function readSession(key) {
    try {
      return window.sessionStorage.getItem(key);
    } catch {
      return null;
    }
  }
  function writeSession(key, value) {
    try {
      window.sessionStorage.setItem(key, value);
    } catch {
    }
  }
  function filterKey(s) {
    return `${s.allClasses ? "all" : "sem"}:${s.excludedCourses.slice().sort().join(",")}`;
  }
  async function teachesSomething(s) {
    let key = `${ROLE_KEY}:${s.allClasses ? "all" : "sem"}`;
    try {
      let c = JSON.parse(readSession(key) || "null");
      if (c && typeof c.t == "number" && Date.now() - c.t < ROLE_TTL_MS && (c.v === 0 || c.v === 1)) return c.v === 1;
    } catch {
    }
    let { items } = await canvasGetAll(
      "/api/v1/courses?enrollment_state=active&include[]=term&per_page=100",
      4
    ), now = /* @__PURE__ */ new Date(), yes = items.some((c) => isShownCourse(c, now, s.allClasses));
    return writeSession(key, JSON.stringify({ v: yes ? 1 : 0, t: Date.now() })), yes;
  }
  function cachedBadge(s) {
    try {
      let raw = readSession(BADGE_KEY);
      if (!raw) return null;
      let v = JSON.parse(raw);
      if (typeof v.n == "number" && typeof v.t == "number" && v.k === filterKey(s) && Date.now() - v.t < BADGE_TTL_MS)
        return v.n;
    } catch {
    }
    return null;
  }
  function sendBadge(n) {
    try {
      chrome.runtime.sendMessage({ type: "badge", count: n ?? 0 }).catch(() => {
      });
    } catch {
    }
  }
  async function start() {
    if (!onAllowedOrigin() || window.top !== window || document.body.classList.contains("is-masquerading-or-student-view")) return null;
    let settings = await loadSettings();
    try {
      if (!await teachesSomething(settings)) return null;
    } catch {
      return null;
    }
    let path = window.location.pathname, courseId = courseIdFromPath(path), loader = new Loader(), card = null, setBadge = (n) => {
      panel.setBadge(n), sendBadge(n), n !== null && writeSession(BADGE_KEY, JSON.stringify({ n, t: Date.now(), k: filterKey(settings) }));
    }, panel = new Panel({
      settings,
      loader,
      currentCourseId: courseId,
      showButton: !1,
      openSettings: () => {
        try {
          chrome.runtime.sendMessage({ type: "open-settings" }).catch(() => {
          });
        } catch {
        }
      },
      onClosed: () => card?.focusLast(),
      onDataChanged: () => card?.refresh()
    });
    document.documentElement.appendChild(panel.host);
    let kind = cardKind(path);
    if (kind) {
      let wanted = kind === "dashboard";
      if (kind === "course")
        try {
          wanted = (await loader.courses(settings.excludedCourses, settings.allClasses)).some((c) => c.id === courseId);
        } catch {
          wanted = !1;
        }
      wanted && kind === "course" && moveTodoUp(document);
      let slot = wanted ? cardSlot(document, kind) : null;
      if (slot) {
        let c = new SidebarCard({
          loader,
          settings,
          courseId: kind === "course" ? courseId : null,
          onOpen: (tab) => {
            panel.openAt(tab, kind === "course" ? courseId : "all");
          },
          onGradeCount: kind === "dashboard" ? (n) => setBadge(n) : void 0
        });
        card = c, slot.parent.insertBefore(c.host, slot.before), c.load();
        let side = slot.parent, watchRoot = side.parentElement ?? side, queued = !1, keepInPlace = () => {
          queued = !1, kind === "course" && moveTodoUp(document);
          let now = cardSlot(document, kind);
          if (!now) return placeButton();
          inSlot(c.host, now) || (now.parent.insertBefore(c.host, now.before), c.refocusAfterMove()), placeButton();
        };
        new MutationObserver(() => {
          queued || (queued = !0, window.requestAnimationFrame(keepInPlace));
        }).observe(watchRoot, { childList: !0, subtree: !0 });
        try {
          new ResizeObserver(() => placeButton()).observe(c.host);
        } catch {
        }
      }
    }
    let placeButton = () => {
      if (card && isShown(card.host)) return panel.setLauncherVisible(!1);
      if (card) return panel.setLauncherVisible(!0);
      if (isGradingPage(path)) return panel.setLauncherVisible(settings.buttonOnGradingPages);
      panel.setLauncherVisible(settings.buttonElsewhere);
    };
    placeButton();
    let t;
    window.addEventListener("resize", () => {
      window.clearTimeout(t), t = window.setTimeout(placeButton, 200);
    }), onSettingsChanged((s) => {
      let reload = filterKey(s) !== filterKey(settings) || s.missingThreshold !== settings.missingThreshold;
      settings = s, panel.updateSettings(s), reload && clearCardCache(), card?.updateSettings(s), reload && showCachedBadge(), placeButton();
    });
    function showCachedBadge() {
      let cached = cachedBadge(settings);
      panel.setBadge(cached), sendBadge(cached);
    }
    return showCachedBadge(), panel.onGradeTotal = (n) => setBadge(n), { panel, card };
  }
  typeof chrome < "u" && chrome.runtime?.id && start();
})();
