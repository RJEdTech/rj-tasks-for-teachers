"use strict";
(() => {
  // src/lib/constants.ts
  var PRODUCT_NAME = "RJ Tasks for Teachers", ALLOWED_ORIGINS = ["https://rjhs.instructure.com"];

  // src/lib/canvasApi.ts
  var ID = "\\d{1,20}", ENDPOINTS = [
    /^\/api\/v1\/courses$/,
    new RegExp(`^/api/v1/courses/${ID}/assignments$`),
    new RegExp(`^/api/v1/courses/${ID}/assignment_groups$`),
    new RegExp(`^/api/v1/courses/${ID}/students/submissions$`),
    new RegExp(`^/api/v1/courses/${ID}/grading_periods$`),
    new RegExp(`^/api/v1/courses/${ID}/users$`),
    /^\/api\/v1\/users\/self\/todo_item_count$/
  ], CanvasApiError = class extends Error {
    constructor(message, status = 0) {
      super(message), this.name = "CanvasApiError", this.status = status;
    }
  };
  function onAllowedOrigin() {
    return ALLOWED_ORIGINS.includes(window.location.origin);
  }
  function assertId(id) {
    let s = String(id ?? "");
    if (!/^\d{1,20}$/.test(s)) throw new CanvasApiError("Rejected invalid id");
    return s;
  }
  function resolveApiUrl(pathOrUrl) {
    if (!onAllowedOrigin())
      throw new CanvasApiError("RJ Tasks for Teachers only runs on RJ Canvas");
    let url;
    try {
      url = new URL(pathOrUrl, window.location.origin);
    } catch {
      throw new CanvasApiError("Rejected malformed URL");
    }
    if (url.origin !== window.location.origin)
      throw new CanvasApiError("Rejected cross-origin request");
    if (url.username || url.password)
      throw new CanvasApiError("Rejected URL with credentials");
    if (!ENDPOINTS.some((re) => re.test(url.pathname)))
      throw new CanvasApiError("Rejected endpoint " + url.pathname);
    return url;
  }
  function parseCanvasJson(text) {
    let body = text.replace(/^while\(1\);/, "").trim();
    return body ? JSON.parse(body) : null;
  }
  function nextLink(linkHeader) {
    if (!linkHeader) return null;
    let re = /<([^>]+)>;\s*rel="([^"]+)"/g, m;
    for (; (m = re.exec(linkHeader)) !== null; ) if (m[2] === "next") return m[1];
    return null;
  }
  async function getPage(pathOrUrl) {
    let url = resolveApiUrl(pathOrUrl), res = await fetch(url.toString(), {
      method: "GET",
      headers: { Accept: "application/json+canvas-string-ids, application/json" },
      credentials: "same-origin",
      redirect: "error",
      cache: "no-store",
      referrerPolicy: "same-origin"
    }), text = await res.text();
    if (!res.ok) throw new CanvasApiError(`Canvas returned ${res.status}`, res.status);
    return { data: parseCanvasJson(text), next: nextLink(res.headers.get("link")) };
  }
  async function canvasGet(path) {
    return (await getPage(path)).data;
  }
  async function canvasGetAll(path, maxPages = 25) {
    let items = [], next = path, seen = /* @__PURE__ */ new Set();
    for (let i = 0; next; i++) {
      if (i >= maxPages) return { items, truncated: !0 };
      let url;
      try {
        url = resolveApiUrl(next).toString();
      } catch (err) {
        if (i === 0) throw err;
        return { items, truncated: !0 };
      }
      if (seen.has(url)) break;
      seen.add(url);
      try {
        let page = await getPage(url);
        if (!Array.isArray(page.data)) break;
        items.push(...page.data), next = page.next;
      } catch (err) {
        if (i === 0) throw err;
        return { items, truncated: !0 };
      }
    }
    return { items, truncated: !1 };
  }
  function canvasLink(template, ids) {
    let path = template.replace(/:(\w+)/g, (_, k) => assertId(ids[k])), url = new URL(path, window.location.origin);
    if (url.origin !== window.location.origin) throw new CanvasApiError("Rejected link");
    return url.toString();
  }
  async function mapLimit(items, limit, fn) {
    let out = new Array(items.length), i = 0, workers = Array.from({ length: Math.min(limit, items.length) }, async () => {
      for (; i < items.length; ) {
        let idx = i++;
        out[idx] = await fn(items[idx]);
      }
    });
    return await Promise.all(workers), out;
  }

  // src/lib/dates.ts
  function parse(iso) {
    if (!iso) return null;
    let d = new Date(iso);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  function dayKey(d) {
    let y = d.getFullYear(), m = String(d.getMonth() + 1).padStart(2, "0"), day = String(d.getDate()).padStart(2, "0");
    return `${y}-${m}-${day}`;
  }
  function startOfDay(d) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
  }
  function addDays(d, n) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate() + n);
  }
  function isLocalMidnight(d) {
    return d.getHours() === 0 && d.getMinutes() === 0 && d.getSeconds() === 0;
  }
  var dayFmt = new Intl.DateTimeFormat("en-US", { weekday: "short", month: "short", day: "numeric" }), timeFmt = new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" });
  function formatDay(d) {
    return dayFmt.format(d);
  }
  function formatDayTime(d) {
    return `${dayFmt.format(d)}, ${timeFmt.format(d)}`;
  }
  function waitingFor(since, now) {
    let days = Math.floor((startOfDay(now).getTime() - startOfDay(since).getTime()) / 864e5);
    return days <= 0 ? "today" : days === 1 ? "1 day" : `${days} days`;
  }
  function daysBetween(a, b) {
    return Math.round((startOfDay(b).getTime() - startOfDay(a).getTime()) / 864e5);
  }

  // src/data/courses.ts
  var TEACHING = /* @__PURE__ */ new Set(["teacher", "ta"]);
  function isCurrentTeachingCourse(c, now) {
    if (!c.enrollments?.some((e) => TEACHING.has(e.type)) || c.workflow_state !== void 0 && c.workflow_state !== "available") return !1;
    let end = (c.restrict_enrollments_to_course_dates ? parse(c.end_at) : null) ?? parse(c.term?.end_at ?? null);
    return !(end && end.getTime() < now.getTime());
  }
  function toTeacherCourse(c) {
    return {
      id: String(c.id),
      name: c.name || c.course_code || "Course",
      code: c.course_code || c.name || "Course",
      weighted: !!c.apply_assignment_group_weights
    };
  }
  function teacherCourses(all, now, excluded = []) {
    let skip = new Set(excluded.map(String));
    return all.filter((c) => isCurrentTeachingCourse(c, now)).map(toTeacherCourse).filter((c) => !skip.has(c.id)).sort((a, b) => a.code.localeCompare(b.code, "en", { numeric: !0 }));
  }

  // src/data/assignments.ts
  function datesOf(a) {
    return a.all_dates && a.all_dates.length ? a.all_dates : [{ base: !0, due_at: a.due_at, lock_at: a.lock_at ?? null, unlock_at: a.unlock_at ?? null }];
  }
  function dueDates(a) {
    return datesOf(a).map((d) => parse(d.due_at)).filter((d) => !!d);
  }
  function isGraded(a) {
    return a.grading_type !== "not_graded" && !a.omit_from_final_grade;
  }
  function byId(list) {
    return new Map(list.map((a) => [String(a.id), a]));
  }

  // src/data/grading.ts
  function buildQueue(course, assignments, submissions) {
    let map = byId(assignments), rows = /* @__PURE__ */ new Map(), counted = /* @__PURE__ */ new Set();
    for (let s of submissions) {
      if (s.workflow_state !== "submitted" && s.workflow_state !== "pending_review" || s.excused) continue;
      let aid = String(s.assignment_id), a = map.get(aid);
      if (!a || a.grading_type === "not_graded") continue;
      let once = `${aid}:${s.user_id}`;
      if (counted.has(once)) continue;
      counted.add(once);
      let row = rows.get(aid);
      row || (row = {
        course,
        assignmentId: aid,
        name: a.name,
        count: 0,
        late: 0,
        resubmitted: 0,
        review: 0,
        oldest: null,
        dueAt: parse(a.due_at)
      }, rows.set(aid, row)), row.count++, s.late && row.late++, s.workflow_state === "pending_review" ? row.review++ : s.grade != null && s.grade_matches_current_submission === !1 && row.resubmitted++;
      let at = parse(s.submitted_at);
      at && (!row.oldest || at < row.oldest) && (row.oldest = at);
    }
    return [...rows.values()];
  }
  function queueFromCounts(course, assignments) {
    return assignments.filter((a) => (a.needs_grading_count ?? 0) > 0 && a.grading_type !== "not_graded").map((a) => ({
      course,
      assignmentId: String(a.id),
      name: a.name,
      count: a.needs_grading_count ?? 0,
      late: 0,
      resubmitted: 0,
      review: 0,
      oldest: null,
      dueAt: parse(a.due_at)
    }));
  }
  function sortQueue(rows) {
    return [...rows].sort((a, b) => a.oldest && b.oldest && a.oldest.getTime() !== b.oldest.getTime() ? a.oldest.getTime() - b.oldest.getTime() : a.oldest && !b.oldest ? -1 : !a.oldest && b.oldest ? 1 : b.count - a.count || a.name.localeCompare(b.name));
  }

  // src/data/checkup.ts
  var WEIGHT_TOLERANCE = 0.05, ATTENDANCE = /^roll call attendance$/i;
  function issueKey(courseId, rule, id) {
    return `${courseId}:${rule}:${id}`;
  }
  function runCheckup(course, assignments, groups, now) {
    let out = [], soon = addDays(now, 3).getTime(), recent = addDays(now, -14).getTime(), horizon = addDays(now, 21).getTime(), add = (rule, severity, a, detail, sortDate = Number.MAX_SAFE_INTEGER) => out.push({
      key: issueKey(course.id, rule, String(a.id)),
      course,
      rule,
      severity,
      title: a.name,
      detail,
      link: { kind: "assignment_edit", assignmentId: String(a.id) },
      sortDate
    });
    for (let a of assignments) {
      let dates = datesOf(a), due = dueDates(a), graded = isGraded(a);
      if (a.published && graded && due.length === 0 && !ATTENDANCE.test(a.name.trim()) && add("no_due_date", "fix", a, "No due date, so it won't appear in students' To Do list, calendar or RJ Tasks."), !a.published) {
        let close = due.filter((d) => d.getTime() <= soon && d.getTime() >= recent).sort((x, y) => x.getTime() - y.getTime())[0];
        if (close) {
          let past = close.getTime() < now.getTime();
          add(
            "unpublished_due",
            "fix",
            a,
            past ? `Not published, and it was due ${formatDayTime(close)}. Students can't see or submit it.` : `Not published, but it's due ${formatDayTime(close)}. Students can't see it yet.`,
            close.getTime()
          );
        }
      }
      for (let d of dates) {
        let dueAt = parse(d.due_at), lockAt = parse(d.lock_at ?? null);
        if (dueAt && lockAt && lockAt.getTime() < dueAt.getTime() && a.published) {
          let who = !d.base && d.title ? ` for ${d.title}` : "";
          add(
            "locks_before_due",
            "fix",
            a,
            `Locks ${formatDayTime(lockAt)}${who}, before it's due ${formatDayTime(dueAt)}. Students can't submit on time.`,
            dueAt.getTime()
          );
          break;
        }
      }
      if (a.published && graded && (a.grading_type === "points" || a.grading_type === "percent") && !((a.points_possible ?? 0) > 0) && add("zero_points", "check", a, "Worth 0 points, so it won't change anyone's grade."), a.published) {
        let midnight = due.filter((d) => d.getTime() > now.getTime() && d.getTime() <= horizon && isLocalMidnight(d)).sort((x, y) => x.getTime() - y.getTime())[0];
        if (midnight) {
          let nightBefore = addDays(midnight, -1);
          add(
            "midnight_due",
            "check",
            a,
            `Due at 12:00 AM on ${formatDay(midnight)}, which is the end of ${weekday(nightBefore)}. Students often read it as ${weekday(midnight)} night. If you meant ${weekday(nightBefore)} night, 11:59 PM is clearer.`,
            midnight.getTime()
          );
        }
      }
    }
    if (course.weighted && groups.length) {
      let total = groups.reduce((s, g) => s + (g.group_weight ?? 0), 0);
      Math.abs(total - 100) > WEIGHT_TOLERANCE && out.push({
        key: issueKey(course.id, "weights_total", "course"),
        course,
        rule: "weights_total",
        severity: "fix",
        title: "Assignment group weights",
        detail: total < 100 ? `The weights add up to ${round(total)}%, not 100%. Canvas scales them up, so each group counts for more than its weight says.` : `The weights add up to ${round(total)}%, more than 100%. Canvas doesn't scale them down, so class grades can come out higher than they should.`,
        link: { kind: "assignments_index" },
        sortDate: 0
      });
      for (let g of groups) {
        if ((g.group_weight ?? 0) !== 0) continue;
        let counted = assignments.filter(
          (a) => String(a.assignment_group_id) === String(g.id) && a.published && isGraded(a) && (a.points_possible ?? 0) > 0
        );
        counted.length && out.push({
          key: issueKey(course.id, "zero_weight_group", String(g.id)),
          course,
          rule: "zero_weight_group",
          severity: "check",
          title: g.name,
          detail: `This group is weighted 0%, so its ${counted.length} graded assignment${counted.length === 1 ? "" : "s"} don't count toward the class grade.`,
          link: { kind: "assignments_index" },
          sortDate: 1
        });
      }
    }
    return out;
  }
  function sortIssues(issues) {
    let sev = (s) => s === "fix" ? 0 : 1;
    return [...issues].sort(
      (a, b) => sev(a.severity) - sev(b.severity) || a.sortDate - b.sortDate || a.course.code.localeCompare(b.course.code, "en", { numeric: !0 }) || a.title.localeCompare(b.title)
    );
  }
  function weekday(d) {
    return d.toLocaleDateString("en-US", { weekday: "long" });
  }
  function round(n) {
    return Number.isInteger(n) ? String(n) : n.toFixed(2).replace(/0$/, "");
  }

  // src/data/students.ts
  function currentPeriod(periods, now) {
    return periods.find((p) => {
      let s = parse(p.start_date), e = parse(p.end_date);
      return (!s || s <= now) && (!e || now <= e);
    }) ?? null;
  }
  function pastDueIds(assignments, period, now) {
    let start2 = parse(period?.start_date ?? null), end = parse(period?.end_date ?? null);
    return assignments.filter((a) => a.published && isGraded(a)).filter(
      (a) => dueDates(a).some((d) => d < now && (!start2 || d >= start2) && (!end || d <= end))
    ).map((a) => String(a.id));
  }
  function buildStudents(course, users, submissions, assignments, threshold) {
    let people = new Map(users.map((u) => [String(u.id), u])), map = byId(assignments), rows = /* @__PURE__ */ new Map(), seen = /* @__PURE__ */ new Set();
    for (let s of submissions) {
      if (!s.missing || s.excused) continue;
      let uid = String(s.user_id), u = people.get(uid), a = map.get(String(s.assignment_id));
      if (!u || !a) continue;
      let once = `${uid}:${a.id}`;
      if (seen.has(once)) continue;
      seen.add(once);
      let row = rows.get(uid);
      row || (row = { course, userId: uid, name: u.name, sortableName: u.sortable_name || u.name, missing: [] }, rows.set(uid, row)), row.missing.push({
        assignmentId: String(a.id),
        name: a.name,
        dueAt: parse(s.cached_due_date ?? null) ?? parse(a.due_at)
      });
    }
    return [...rows.values()].filter((r) => r.missing.length >= threshold).map((r) => ({
      ...r,
      missing: [...r.missing].sort((x, y) => (x.dueAt?.getTime() ?? 0) - (y.dueAt?.getTime() ?? 0))
    })).sort((a, b) => b.missing.length - a.missing.length || a.sortableName.localeCompare(b.sortableName));
  }
  function studentsAsText(rows) {
    let lines = [], course = "";
    for (let r of rows)
      r.course.id !== course && (lines.length && lines.push(""), course = r.course.id, lines.push(r.course.code === r.course.name ? r.course.name : `${r.course.code} · ${r.course.name}`)), lines.push(`${r.name} (${r.missing.length} missing): ${r.missing.map((m) => m.name).join("; ")}`);
    return lines.join(`
`);
  }
  function chunk(list, size) {
    let out = [];
    for (let i = 0; i < list.length; i += size) out.push(list.slice(i, i + size));
    return out;
  }

  // src/data/week.ts
  function buildWeek(data, now, days = 7) {
    let first = startOfDay(now), out = Array.from({ length: days }, (_, i) => {
      let date = addDays(first, i);
      return { date, key: dayKey(date), items: [], flags: [] };
    }), index = new Map(out.map((d) => [d.key, d]));
    for (let { course, assignments } of data)
      for (let a of assignments) {
        if (!a.published) continue;
        let seenHere = /* @__PURE__ */ new Set();
        for (let d of datesOf(a)) {
          let due = parse(d.due_at);
          if (!due) continue;
          let day = index.get(dayKey(due));
          if (!day) continue;
          let { scope, forWhom } = whoFor(d), k = `${day.key}:${forWhom ?? ""}`;
          seenHere.has(k) || (seenHere.add(k), day.items.push({
            course,
            assignmentId: String(a.id),
            name: a.name,
            dueAt: due,
            points: a.points_possible,
            graded: isGraded(a) && (a.points_possible ?? 0) > 0,
            forWhom,
            scope
          }));
        }
      }
    for (let day of out)
      day.items.sort(
        (x, y) => x.dueAt.getTime() - y.dueAt.getTime() || x.course.code.localeCompare(y.course.code, "en", { numeric: !0 }) || x.name.localeCompare(y.name)
      ), day.flags = flagsFor(day.items);
    return out;
  }
  var STUDENTS_TITLE = /^\d+ students?$/i;
  function whoFor(d) {
    if (d.base) return { scope: "all", forWhom: null };
    let title = (d.title || "").trim();
    return d.set_type === "ADHOC" || d.set_type === "Group" || STUDENTS_TITLE.test(title) ? { scope: "some", forWhom: title || "some students" } : d.set_type === "CourseSection" || title ? { scope: "section", forWhom: title || null } : { scope: "all", forWhom: null };
  }
  function flagsFor(items) {
    let flags = [], byCourse = /* @__PURE__ */ new Map();
    for (let it of items) {
      if (!it.graded || it.scope === "some") continue;
      let list = byCourse.get(it.course.id) ?? [];
      list.push(it), byCourse.set(it.course.id, list);
    }
    for (let list of byCourse.values()) {
      let course = list[0].course, everyone = list.filter((i) => i.scope === "all").length;
      everyone >= 2 && flags.push({ course, forWhom: null, count: everyone });
      let sections = /* @__PURE__ */ new Map();
      for (let i of list) i.scope === "section" && i.forWhom && sections.set(i.forWhom, (sections.get(i.forWhom) ?? 0) + 1);
      for (let [name, n] of sections) everyone + n >= 2 && flags.push({ course, forWhom: name, count: everyone + n });
    }
    return flags;
  }

  // src/data/loader.ts
  var PARALLEL = 3, IDS_PER_REQUEST = 20, Loader = class {
    constructor(now = () => /* @__PURE__ */ new Date()) {
      this.now = now;
      this.memo = /* @__PURE__ */ new Map();
    }
    reset() {
      this.memo.clear();
    }
    once(key, fn) {
      let p = this.memo.get(key);
      return p || (p = fn(), this.memo.set(key, p), p.catch(() => this.memo.delete(key))), p;
    }
    courses(excluded = []) {
      return this.once("courses", async () => {
        let { items } = await canvasGetAll(
          "/api/v1/courses?enrollment_state=active&include[]=term&per_page=100"
        );
        return items;
      }).then((all) => teacherCourses(all, this.now(), excluded));
    }
    assignments(cid) {
      let id = assertId(cid);
      return this.once(`a:${id}`, async () => {
        let { items } = await canvasGetAll(
          `/api/v1/courses/${id}/assignments?include[]=all_dates&per_page=100`
        );
        return items;
      });
    }
    groups(cid) {
      let id = assertId(cid);
      return this.once(`g:${id}`, async () => {
        let { items } = await canvasGetAll(
          `/api/v1/courses/${id}/assignment_groups?per_page=100`
        );
        return items;
      });
    }
    /* Active students only: the Test Student, dropped and concluded students are left out. */
    users(cid) {
      let id = assertId(cid);
      return this.once(`u:${id}`, async () => {
        let { items } = await canvasGetAll(
          `/api/v1/courses/${id}/users?enrollment_type[]=student&enrollment_state[]=active&per_page=100`
        );
        return items;
      });
    }
    activeOnly(subs, users) {
      if (!users) return subs;
      let ids = new Set(users.map((u) => String(u.id)));
      return subs.filter((s) => ids.has(String(s.user_id)));
    }
    toGradeSubmissions(cid) {
      let id = assertId(cid);
      return this.once(`s:${id}`, async () => {
        let lists = await Promise.all(
          ["submitted", "pending_review"].map(
            (state) => canvasGetAll(
              `/api/v1/courses/${id}/students/submissions?student_ids[]=all&enrollment_state=active&workflow_state=${state}&per_page=100`
            )
          )
        );
        return { subs: lists.flatMap((l) => l.items), partial: lists.some((l) => l.truncated) };
      });
    }
    async toGrade(courses) {
      let failed = [], partial = !1, rows = await mapLimit(courses, PARALLEL, async (c) => {
        let assignments;
        try {
          assignments = await this.assignments(c.id);
        } catch {
          return failed.push(c), [];
        }
        try {
          let [r, users] = await Promise.all([
            this.toGradeSubmissions(c.id),
            this.users(c.id).catch(() => null)
          ]);
          return partial ||= r.partial, buildQueue(c, assignments, this.activeOnly(r.subs, users));
        } catch {
          return queueFromCounts(c, assignments);
        }
      });
      return { value: sortQueue(rows.flat()), failed, partial };
    }
    async checkup(courses, ignored) {
      let failed = [], now = this.now(), all = await mapLimit(courses, PARALLEL, async (c) => {
        try {
          let [a, g] = await Promise.all([this.assignments(c.id), this.groups(c.id)]);
          return runCheckup(c, a, g, now);
        } catch {
          return failed.push(c), [];
        }
      });
      return { value: sortIssues(all.flat().filter((i) => !ignored.has(i.key))), failed, partial: !1 };
    }
    async period(cid) {
      let id = assertId(cid);
      try {
        let r = await this.once(
          `p:${id}`,
          () => canvasGet(
            `/api/v1/courses/${id}/grading_periods?per_page=100`
          )
        );
        return currentPeriod(r?.grading_periods ?? [], this.now());
      } catch {
        return null;
      }
    }
    /* Every submission Canvas flags Missing, whatever its state: Canvas's
       missing-submission policy grades missing work (state "graded") but keeps
       the Missing flag, and so does a teacher's own "Missing" mark with a 0. */
    missing(c) {
      let id = assertId(c.id);
      return this.once(`m:${id}`, async () => {
        let [assignments, period, users] = await Promise.all([
          this.assignments(id),
          this.period(id),
          this.users(id)
        ]), ids = pastDueIds(assignments, period, this.now()), submissions = [], partial = !1;
        for (let part of chunk(ids, IDS_PER_REQUEST)) {
          let q = part.map((a) => `assignment_ids[]=${assertId(a)}`).join("&"), r = await canvasGetAll(
            `/api/v1/courses/${id}/students/submissions?student_ids[]=all&enrollment_state=active&${q}&per_page=100`
          );
          partial ||= r.truncated, submissions.push(...r.items.filter((s) => s.missing && !s.excused));
        }
        return { course: c, users, assignments, submissions, partial, periodKnown: !!period };
      });
    }
    async students(courses, threshold) {
      let failed = [], partial = !1, periodKnown = !0;
      return { value: (await mapLimit(courses, PARALLEL, async (c) => {
        try {
          let m = await this.missing(c);
          return partial ||= m.partial, periodKnown &&= m.periodKnown, buildStudents(c, m.users, m.submissions, m.assignments, threshold);
        } catch {
          return failed.push(c), [];
        }
      })).flat(), failed, partial, periodKnown };
    }
    async week(courses) {
      let failed = [], data = await mapLimit(courses, PARALLEL, async (c) => {
        try {
          return { course: c, assignments: await this.assignments(c.id) };
        } catch {
          return failed.push(c), { course: c, assignments: [] };
        }
      });
      return { value: buildWeek(data, this.now()), failed, partial: !1 };
    }
  };
  async function needsGradingCount() {
    try {
      let r = await canvasGet("/api/v1/users/self/todo_item_count");
      return typeof r?.needs_grading_count == "number" ? r.needs_grading_count : null;
    } catch {
      return null;
    }
  }

  // src/lib/settings.ts
  var DEFAULTS = {
    missingThreshold: 3,
    hideNames: !0,
    excludedCourses: [],
    buttonOnGradingPages: !1
  }, THRESHOLDS = [1, 2, 3, 4, 5];
  function clean(raw) {
    let r = raw && typeof raw == "object" ? raw : {};
    return {
      missingThreshold: THRESHOLDS.includes(r.missingThreshold) ? r.missingThreshold : DEFAULTS.missingThreshold,
      hideNames: typeof r.hideNames == "boolean" ? r.hideNames : DEFAULTS.hideNames,
      excludedCourses: Array.isArray(r.excludedCourses) ? r.excludedCourses.map(String).filter((s) => /^\d{1,20}$/.test(s)).slice(0, 200) : [],
      buttonOnGradingPages: typeof r.buttonOnGradingPages == "boolean" ? r.buttonOnGradingPages : DEFAULTS.buttonOnGradingPages
    };
  }
  async function loadSettings() {
    try {
      let got = await chrome.storage.sync.get("settings");
      return clean(got.settings);
    } catch {
      return { ...DEFAULTS };
    }
  }
  async function saveSettings(s) {
    await chrome.storage.sync.set({ settings: clean(s) });
  }
  function onSettingsChanged(fn) {
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        area === "sync" && changes.settings && fn(clean(changes.settings.newValue));
      });
    } catch {
    }
  }
  var IGNORE_KEY = /^\d{1,20}:[a-z_]{1,30}:(\d{1,20}|course)$/;
  async function loadIgnored() {
    try {
      let got = await chrome.storage.local.get("ignored"), list = Array.isArray(got.ignored) ? got.ignored : [];
      return new Set(list.filter((k) => typeof k == "string" && IGNORE_KEY.test(k)));
    } catch {
      return /* @__PURE__ */ new Set();
    }
  }
  async function setIgnored(keys) {
    let list = [...keys].filter((k) => IGNORE_KEY.test(k)).slice(-2e3);
    await chrome.storage.local.set({ ignored: list });
  }
  async function saveKnownCourses(list) {
    let clean2 = list.filter((c) => /^\d{1,20}$/.test(String(c.id))).slice(0, 100).map((c) => ({ id: String(c.id), code: String(c.code).slice(0, 120), name: String(c.name).slice(0, 200) }));
    await chrome.storage.local.set({ knownCourses: clean2 });
  }

  // src/ui/styles.ts
  var CSS = `
:host { all: initial; }
* { box-sizing: border-box; }
[hidden] { display: none !important; }
.wrap {
  --bg: #ffffff; --fg: #1f2329; --muted: #5b6168; --line: #d8dbe0; --card: #f6f7f9;
  --red: #C11430; --red-text: #a3122a; --warn-bg: #fff4e5; --warn-fg: #7a4100;
  --fix-bg: #fdecef; --link: #0b5cad; --focus: #2563eb;
  font: 16px/1.5 "Segoe UI", system-ui, -apple-system, Roboto, Arial, sans-serif;
  color: var(--fg);
}
@media (prefers-color-scheme: dark) {
  .wrap {
    --bg: #15161a; --fg: #e8e9ec; --muted: #a9adb4; --line: #33363d; --card: #1d1f24;
    --red-text: #ed516a; --warn-bg: #3a2a12; --warn-fg: #ffd28a; --fix-bg: #3a1a20; --link: #8ab8ff;
  }
}
button, select { font: inherit; color: inherit; }
:focus-visible { outline: 3px solid var(--focus); outline-offset: 2px; }

.launcher {
  position: fixed; right: 20px; bottom: 20px; z-index: 2147483000;
  display: inline-flex; align-items: center; gap: 8px;
  padding: 10px 16px; border-radius: 999px; border: 0; cursor: pointer;
  background: #2a2a2a; color: #fff; font-weight: 600; font-size: 15px;
  box-shadow: 0 4px 14px rgba(0,0,0,.25); border-bottom: 3px solid var(--red);
}
.launcher:hover { background: #3a3a3a; }
.badge {
  min-width: 24px; padding: 0 7px; border-radius: 999px; background: var(--red);
  color: #fff; font-size: 14px; line-height: 24px; text-align: center;
}

.panel {
  position: fixed; top: 0; right: 0; bottom: 0; z-index: 2147483001;
  width: min(460px, 100vw); display: flex; flex-direction: column;
  background: var(--bg); color: var(--fg); border-left: 1px solid var(--line);
  box-shadow: -8px 0 24px rgba(0,0,0,.18);
}
.mast { background: #2a2a2a; color: #fff; border-bottom: 6px solid var(--red); padding: 14px 16px 12px; display: flex; align-items: center; gap: 12px; }
.mark { width: 34px; height: 34px; border-radius: 6px; background: var(--red); color: #fff; font-weight: 800; font-size: 15px; display: grid; place-items: center; letter-spacing: .02em; flex: none; }
.mast h2 { margin: 0; font-size: 18px; font-weight: 700; line-height: 1.2; }
.mast .tag { margin: 2px 0 0; color: #b8b8b8; font-size: 13px; text-transform: uppercase; letter-spacing: .12em; }
.mast .close { margin-left: auto; background: transparent; border: 1px solid #555; color: #fff; border-radius: 6px; width: 36px; height: 36px; cursor: pointer; font-size: 18px; line-height: 1; }

.scope { display: flex; align-items: center; gap: 8px; padding: 10px 16px; border-bottom: 1px solid var(--line); }
.scope label { font-size: 14px; color: var(--muted); }
.scope select { flex: 1; min-width: 0; padding: 6px 8px; border: 1px solid var(--line); border-radius: 6px; background: var(--bg); }

.tabs { display: flex; border-bottom: 1px solid var(--line); padding: 0 8px; }
.tab { flex: 1; padding: 10px 4px 8px; background: none; border: 0; border-bottom: 3px solid transparent; cursor: pointer; font-size: 15px; color: var(--muted); font-weight: 600; }
.tab[aria-selected="true"] { color: var(--fg); border-bottom-color: var(--red); }
.tab .n { font-weight: 700; }

.body { flex: 1; overflow-y: auto; padding: 12px 16px 20px; }
.summary { margin: 0 0 12px; font-size: 16px; }
.note { margin: 12px 0 0; font-size: 14px; color: var(--muted); }
.empty { padding: 24px 8px; text-align: center; color: var(--muted); }
h3 { margin: 16px 0 8px; font-size: 13px; text-transform: uppercase; letter-spacing: .08em; color: var(--muted); }
h3:first-child { margin-top: 0; }

.row { display: block; padding: 10px 12px; margin: 0 0 8px; border: 1px solid var(--line); border-radius: 8px; background: var(--card); }
.row.old { border-left: 4px solid var(--red); }
.row.fix { border-left: 4px solid var(--red); }
.row.check { border-left: 4px solid #b26b00; }
.code { display: inline-block; font-size: 13px; font-weight: 700; letter-spacing: .04em; text-transform: uppercase; color: var(--muted); }
.title { display: block; font-weight: 600; color: var(--link); text-decoration: none; overflow-wrap: anywhere; }
a.title:hover { text-decoration: underline; }
.plain { color: var(--fg); }
.meta { display: block; font-size: 14px; color: var(--muted); }
.meta b { color: var(--fg); font-weight: 600; }
.late { color: var(--red-text); font-weight: 600; }
.actions { display: flex; gap: 8px; margin-top: 8px; flex-wrap: wrap; }
.btn { display: inline-flex; align-items: center; padding: 5px 12px; border-radius: 6px; border: 1px solid var(--line); background: var(--bg); color: var(--fg); font-size: 14px; cursor: pointer; text-decoration: none; }
.btn.primary { background: #2a2a2a; color: #fff; border-color: #2a2a2a; }
@media (prefers-color-scheme: dark) { .btn.primary { background: #e8e9ec; color: #15161a; border-color: #e8e9ec; } }

.privacy { display: flex; gap: 10px; align-items: center; justify-content: space-between; padding: 10px 12px; margin: 0 0 12px; border-radius: 8px; background: var(--warn-bg); color: var(--warn-fg); font-size: 14px; }
.count { display: flex; justify-content: space-between; padding: 8px 12px; border: 1px solid var(--line); border-radius: 8px; margin: 0 0 8px; }
details.row > summary { cursor: pointer; list-style: revert; }
details.row ul { margin: 8px 0 0; padding-left: 20px; font-size: 15px; }

.day { margin: 0 0 14px; }
.day h4 { margin: 0 0 6px; font-size: 16px; }
.day h4 .muted { color: var(--muted); font-weight: 400; font-size: 14px; }
.flag { padding: 6px 10px; margin: 0 0 6px; border-radius: 6px; background: var(--warn-bg); color: var(--warn-fg); font-size: 14px; }
.item { display: flex; gap: 8px; padding: 5px 0; border-bottom: 1px solid var(--line); font-size: 15px; }
.item .time { flex: none; width: 74px; color: var(--muted); font-size: 14px; }
.item a { color: var(--link); text-decoration: none; overflow-wrap: anywhere; }
.item .code { display: block; }
.item .pts { margin-left: auto; flex: none; color: var(--muted); font-size: 14px; }

.foot { display: flex; align-items: center; gap: 8px; padding: 10px 16px; border-top: 1px solid var(--line); font-size: 14px; color: var(--muted); }
.foot .spacer { flex: 1; }
.linkbtn { background: none; border: 0; padding: 4px 6px; color: var(--link); cursor: pointer; font-size: 14px; text-decoration: underline; }
.sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); white-space: nowrap; }
`;

  // src/ui/dom.ts
  var ALLOWED_ATTR = /^(class|id|role|type|title|tabindex|hidden|disabled|href|target|rel|value|selected|for|name|open|lang|aria-[a-z]+|data-[a-z-]+)$/;
  function h(tag, attrs = {}, ...children) {
    let el = document.createElement(tag);
    for (let [k, v] of Object.entries(attrs))
      if (!(v == null || v === !1)) {
        if (!ALLOWED_ATTR.test(k)) throw new Error("Refused attribute " + k);
        if (k === "href") {
          el.setAttribute("href", safeLink(String(v)));
          continue;
        }
        el.setAttribute(k, v === !0 ? "" : String(v));
      }
    return append(el, ...children), el;
  }
  function append(el, ...children) {
    for (let c of children)
      c == null || c === !1 || el.appendChild(typeof c == "string" || typeof c == "number" ? document.createTextNode(String(c)) : c);
  }
  function clear(el) {
    for (; el.firstChild; ) el.removeChild(el.firstChild);
  }
  function safeLink(href) {
    try {
      let u = new URL(href, window.location.origin);
      return u.origin === window.location.origin && (u.protocol === "https:" || u.protocol === "http:") ? u.toString() : "#";
    } catch {
      return "#";
    }
  }
  function plural(n, one, many = one + "s") {
    return `${n} ${n === 1 ? one : many}`;
  }

  // src/ui/views.ts
  var OLD_DAYS = 7;
  function codeChip(c, show) {
    return show ? h("span", { class: "code" }, c.code) : null;
  }
  function failedNote(failed, partial) {
    let parts = [];
    return failed.length && parts.push(`Couldn't load ${failed.map((c) => c.code).join(", ")}. Try Refresh, or open the class in Canvas.`), partial && parts.push("Some lists were very long, so a few items may be missing here."), parts.length ? h("p", { class: "note", role: "status" }, parts.join(" ")) : null;
  }
  function gradingView(rows, showCourse, now) {
    let box = h("div");
    if (!rows.length)
      return box.append(h("p", { class: "empty" }, "Nothing is waiting to be graded.")), box;
    let total = rows.reduce((s, r) => s + r.count, 0);
    box.append(
      h("p", { class: "summary" }, `${plural(total, "submission")} to grade in ${plural(rows.length, "assignment")}. Oldest first.`)
    );
    for (let r of rows) {
      let old = !!r.oldest && daysBetween(r.oldest, now) >= OLD_DAYS, href = canvasLink("/courses/:c/gradebook/speed_grader?assignment_id=:a", {
        c: r.course.id,
        a: r.assignmentId
      }), meta = h("span", { class: "meta" }, h("b", {}, `${r.count} to grade`));
      r.late && meta.append(" · ", h("span", { class: "late" }, `${r.late} late`)), r.resubmitted && meta.append(` · ${r.resubmitted} resubmitted`), r.review && meta.append(` · ${r.review} quiz ${r.review === 1 ? "answer" : "answers"} to review`), r.oldest && meta.append(` · oldest waiting ${waitingFor(r.oldest, now)}`), box.append(
        h(
          "div",
          { class: old ? "row old" : "row" },
          codeChip(r.course, showCourse),
          h("a", { class: "title", href }, r.name),
          meta,
          h("div", { class: "actions" }, h("a", { class: "btn primary", href }, "Open SpeedGrader"))
        )
      );
    }
    return box;
  }
  function issueHref(i) {
    return i.link.kind === "assignment_edit" ? canvasLink("/courses/:c/assignments/:a/edit", { c: i.course.id, a: i.link.assignmentId }) : canvasLink("/courses/:c/assignments", { c: i.course.id });
  }
  function checkupView(issues, ignoredHere, showCourse, onIgnore, onUnignore) {
    let box = h("div"), fix = issues.filter((i) => i.severity === "fix"), check = issues.filter((i) => i.severity === "check");
    if (!issues.length)
      box.append(h("p", { class: "empty" }, "No setup problems found."));
    else {
      let bits = [];
      fix.length && bits.push(`${fix.length} to fix`), check.length && bits.push(`${check.length} worth a look`), box.append(h("p", { class: "summary" }, bits.join(", ") + "."));
    }
    let section = (title, list) => {
      if (list.length) {
        box.append(h("h3", {}, title));
        for (let i of list) {
          let ignore = h("button", { class: "btn", type: "button" }, "Ignore");
          ignore.addEventListener("click", () => onIgnore(i)), box.append(
            h(
              "div",
              { class: `row ${i.severity}`, "data-rule": i.rule },
              codeChip(i.course, showCourse),
              h("span", { class: "title plain" }, i.title),
              h("span", { class: "meta" }, i.detail),
              h("div", { class: "actions" }, h("a", { class: "btn primary", href: issueHref(i) }, i.link.kind === "assignment_edit" ? "Edit assignment" : "Open assignments"), ignore)
            )
          );
        }
      }
    };
    if (section("To fix", fix), section("Worth a look", check), ignoredHere) {
      let again = h("button", { class: "linkbtn", type: "button" }, "Show them again");
      again.addEventListener("click", onUnignore), box.append(h("p", { class: "note" }, `${plural(ignoredHere, "item")} ignored. `, again));
    }
    return box.append(
      h(
        "p",
        { class: "note" },
        "Checks: missing due dates, unpublished work that is due, lock dates before due dates, 0-point assignments, 12:00 AM due times, and group weights."
      )
    ), box;
  }
  function studentsView(opts) {
    let { rows, threshold, namesShown, showCourse } = opts, box = h("div"), sel = h("select", { "aria-label": "Minimum missing assignments" });
    for (let n of [1, 2, 3, 4, 5]) sel.append(h("option", { value: n, selected: n === threshold }, String(n)));
    if (sel.addEventListener("change", () => opts.onThreshold(Number(sel.value))), box.append(
      h("p", { class: "summary" }, "Students with at least ", sel, opts.periodKnown ? " missing this grading period." : " missing so far this course.")
    ), !rows.length)
      return box.append(h("p", { class: "empty" }, "No students at that level. Nice.")), box;
    if (!namesShown) {
      let show = h("button", { class: "btn primary", type: "button" }, "Show names");
      show.addEventListener("click", opts.onShowNames), box.append(h("div", { class: "privacy" }, h("span", {}, "Names are hidden in case your screen is shared."), show));
      let byCourse = /* @__PURE__ */ new Map();
      for (let r of rows) {
        let e = byCourse.get(r.course.id) ?? { course: r.course, n: 0 };
        e.n++, byCourse.set(r.course.id, e);
      }
      for (let { course: course2, n } of byCourse.values())
        box.append(h("div", { class: "count" }, h("span", {}, course2.code), h("b", {}, plural(n, "student"))));
      return box;
    }
    let hide = h("button", { class: "btn", type: "button" }, "Hide names");
    hide.addEventListener("click", opts.onHideNames);
    let copy = h("button", { class: "btn", type: "button" }, "Copy list");
    copy.addEventListener("click", opts.onCopy), box.append(h("div", { class: "actions" }, hide, copy));
    let course = "";
    for (let r of rows) {
      showCourse && r.course.id !== course && (course = r.course.id, box.append(h("h3", {}, r.course.code)));
      let list = h("ul");
      for (let m of r.missing)
        list.append(h("li", {}, m.name, m.dueAt ? h("span", { class: "meta" }, `Due ${formatDay(m.dueAt)}`) : null));
      box.append(
        h(
          "details",
          { class: "row" },
          h("summary", {}, h("span", { class: "plain" }, r.name), h("span", { class: "meta" }, `${r.missing.length} missing`)),
          list,
          h(
            "div",
            { class: "actions" },
            h("a", { class: "btn", href: canvasLink("/courses/:c/grades/:u", { c: r.course.id, u: r.userId }) }, "Open grades")
          )
        )
      );
    }
    return box.append(h("p", { class: "note" }, "Uses Canvas's Missing flag, so excused work and your own missing/late marks are respected.")), box;
  }
  var timeFmt2 = new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" });
  function weekView(days, showCourse, now) {
    let box = h("div"), total = days.reduce((s, d) => s + d.items.length, 0), flagged = days.filter((d) => d.flags.length).length;
    return box.append(
      h(
        "p",
        { class: "summary" },
        `${plural(total, "item")} due from your classes in the next 7 days.` + (flagged ? ` ${plural(flagged, "day")} with 2 or more graded items for the same class.` : "")
      )
    ), days.forEach((d, idx) => {
      let label = idx === 0 ? "Today" : idx === 1 ? "Tomorrow" : d.date.toLocaleDateString("en-US", { weekday: "long" }), day = h(
        "div",
        { class: "day" },
        h("h4", {}, label, " ", h("span", { class: "muted" }, `${formatDay(d.date)} · ${plural(d.items.length, "item")}`))
      );
      for (let f of d.flags)
        day.append(
          h(
            "div",
            { class: "flag" },
            `${f.course.code}${f.forWhom ? ` · ${f.forWhom}` : ""}: ${f.count} graded items due this day`
          )
        );
      for (let it of d.items)
        day.append(
          h(
            "div",
            { class: "item" },
            h("span", { class: "time" }, timeFmt2.format(it.dueAt)),
            h(
              "span",
              {},
              showCourse ? h("span", { class: "code" }, it.course.code) : null,
              h("a", { href: canvasLink("/courses/:c/assignments/:a", { c: it.course.id, a: it.assignmentId }) }, it.name),
              it.forWhom ? h("span", { class: "meta" }, it.forWhom) : null
            ),
            it.points != null && it.points > 0 ? h("span", { class: "pts" }, `${it.points} pts`) : null
          )
        );
      box.append(day);
    }), box.append(
      h(
        "p",
        { class: "note" },
        `Shows your classes only. Canvas doesn't let teachers see what students have due in other classes. Updated ${formatDayTime(now)}.`
      )
    ), box;
  }

  // src/ui/panel.ts
  var TABS = [
    ["grade", "To grade"],
    ["checkup", "Check-up"],
    ["students", "Students"],
    ["week", "Week"]
  ], Panel = class {
    constructor(opts) {
      this.opts = opts;
      this.panel = null;
      this.tabButtons = /* @__PURE__ */ new Map();
      this.scope = "all";
      this.tab = "grade";
      this.namesShown = !1;
      this.courses = [];
      this.lastStudents = [];
      this.renderToken = 0;
      this.now = opts.now ?? (() => /* @__PURE__ */ new Date()), this.loader = new Loader(this.now), this.host = document.createElement("div"), this.host.setAttribute("data-rjtt", ""), this.root = this.host.attachShadow({ mode: "closed" }), this.applyStyles(), this.wrap = h("div", { class: "wrap" }), this.root.appendChild(this.wrap), this.badge = h("span", { class: "badge", hidden: !0 }), this.launcher = h(
        "button",
        { class: "launcher", type: "button", "aria-haspopup": "dialog", "aria-expanded": "false" },
        "My Classes",
        this.badge
      ), this.launcher.hidden = !opts.showButton, this.launcher.addEventListener("click", () => this.toggle()), this.wrap.appendChild(this.launcher), document.addEventListener("keydown", (e) => {
        if (e.key !== "Escape" || !this.isOpen()) return;
        let inPanel = e.composedPath().includes(this.host), idle = document.activeElement === document.body || document.activeElement === null;
        !inPanel && !idle || (e.stopPropagation(), this.close());
      }, !0);
    }
    applyStyles() {
      try {
        let sheet = new CSSStyleSheet();
        sheet.replaceSync(CSS), this.root.adoptedStyleSheets = [sheet];
      } catch {
        let style = document.createElement("style");
        style.textContent = CSS, this.root.appendChild(style);
      }
    }
    setBadge(n) {
      n && n > 0 ? (this.badge.textContent = n > 99 ? "99+" : String(n), this.badge.hidden = !1, this.launcher.setAttribute("aria-label", `My Classes, ${plural(n, "assignment")} to grade`)) : (this.badge.hidden = !0, this.launcher.setAttribute("aria-label", "My Classes"));
    }
    updateSettings(s) {
      let prev = this.opts.settings;
      if (this.opts.settings = s, s.hideNames || (this.namesShown = !0), !this.isOpen()) return;
      prev.excludedCourses.join(",") !== s.excludedCourses.join(",") ? this.loadCourses() : (prev.missingThreshold !== s.missingThreshold || prev.hideNames !== s.hideNames) && this.renderTab();
    }
    isOpen() {
      return !!this.panel && !this.panel.hidden;
    }
    toggle() {
      this.isOpen() ? this.close() : this.openPanel();
    }
    close() {
      this.panel && (this.panel.hidden = !0, this.launcher.hidden = !this.opts.showButton, this.launcher.setAttribute("aria-expanded", "false"), this.namesShown = !this.opts.settings.hideNames, this.launcher.focus());
    }
    async openPanel() {
      this.panel || this.build(), this.panel.hidden = !1, this.launcher.hidden = !0, this.launcher.setAttribute("aria-expanded", "true"), this.namesShown = this.namesShown || !this.opts.settings.hideNames, this.panel.querySelector("h2").focus(), await this.loadCourses();
    }
    build() {
      let close = h("button", { class: "close", type: "button", "aria-label": "Close" }, "✕");
      close.addEventListener("click", () => this.close());
      let tabs = h("div", { class: "tabs", role: "tablist", "aria-label": "Views" });
      for (let [id, label] of TABS) {
        let b = h("button", { class: "tab", type: "button", role: "tab", id: `rjtt-tab-${id}`, "aria-selected": "false", "aria-controls": "rjtt-body", "data-tab": id }, label);
        b.addEventListener("click", () => this.select(id)), b.addEventListener("keydown", (e) => {
          let i = TABS.findIndex(([t]) => t === id);
          if (e.key === "ArrowRight" || e.key === "ArrowLeft") {
            let next = TABS[(i + (e.key === "ArrowRight" ? 1 : TABS.length - 1)) % TABS.length][0];
            this.select(next), this.tabButtons.get(next).focus(), e.preventDefault();
          }
        }), this.tabButtons.set(id, b), tabs.append(b);
      }
      this.status = h("span", { role: "status", "aria-live": "polite" });
      let refresh = h("button", { class: "linkbtn", type: "button" }, "Refresh");
      refresh.addEventListener("click", () => {
        this.loader.reset(), this.loadCourses();
      });
      let settings = h("button", { class: "linkbtn", type: "button" }, "Settings");
      settings.addEventListener("click", () => this.opts.openSettings()), this.foot = h("div", { class: "foot" }, this.status, h("span", { class: "spacer" }), refresh, settings), this.body = h("div", { class: "body", id: "rjtt-body", role: "tabpanel", tabindex: "-1" }), this.panel = h(
        "section",
        { class: "panel", role: "dialog", "aria-modal": "false", "aria-labelledby": "rjtt-title" },
        h(
          "div",
          { class: "mast" },
          h("div", { class: "mark", "aria-hidden": "true" }, "RJ"),
          h("div", {}, h("h2", { id: "rjtt-title", tabindex: "-1" }, PRODUCT_NAME), h("p", { class: "tag" }, "Grading · Check-up · Students · Week")),
          close
        ),
        h("div", { class: "scope" }, h("label", { for: "rjtt-scope" }, "Show"), h("select", { id: "rjtt-scope" })),
        tabs,
        this.body,
        this.foot
      ), this.panel.hidden = !0;
      let sel = this.panel.querySelector("select");
      sel.addEventListener("change", () => {
        this.scope = sel.value, this.renderTab();
      }), this.wrap.appendChild(this.panel), this.select(this.tab, !1);
    }
    select(tab, render = !0) {
      this.tab = tab;
      for (let [id, b] of this.tabButtons)
        b.setAttribute("aria-selected", String(id === tab)), b.tabIndex = id === tab ? 0 : -1;
      this.body.setAttribute("aria-labelledby", `rjtt-tab-${tab}`), render && this.renderTab();
    }
    setStatus(text) {
      this.status.textContent = text;
    }
    async loadCourses() {
      clear(this.body), this.body.append(h("p", { class: "empty" }, "Loading your classes…")), this.setStatus("Loading…");
      try {
        this.courses = await this.loader.courses(this.opts.settings.excludedCourses), this.loader.courses([]).then((all) => saveKnownCourses(all)).catch(() => {
        });
      } catch {
        clear(this.body), this.body.append(h("p", { class: "empty" }, "Couldn't reach Canvas. Check that you're signed in, then click Refresh.")), this.setStatus("");
        return;
      }
      let sel = this.panel.querySelector("select");
      clear(sel), sel.append(h("option", { value: "all" }, `All my classes (${this.courses.length})`));
      for (let c of this.courses) sel.append(h("option", { value: c.id }, c.code === c.name ? c.name : `${c.code} · ${c.name}`));
      let cur = this.opts.currentCourseId;
      this.scope === "all" && cur && this.courses.some((c) => c.id === cur) && (this.scope = cur), this.scope !== "all" && !this.courses.some((c) => c.id === this.scope) && (this.scope = "all"), sel.value = this.scope, this.renderTab();
    }
    inScope() {
      return this.scope === "all" ? this.courses : this.courses.filter((c) => c.id === this.scope);
    }
    async renderTab() {
      if (!this.panel) return;
      let token = ++this.renderToken, courses = this.inScope(), showCourse = this.scope === "all";
      if (clear(this.body), !this.courses.length) {
        this.body.append(
          h("p", { class: "empty" }, "You aren't listed as the teacher of any current Canvas classes."),
          h("p", { class: "note" }, "If that seems wrong, check Settings for classes you turned off.")
        ), this.setStatus("");
        return;
      }
      this.body.append(h("p", { class: "empty" }, "Loading…")), this.setStatus("Loading…");
      let now = this.now(), content, note = null;
      try {
        if (this.tab === "grade") {
          let r = await this.loader.toGrade(courses);
          content = gradingView(r.value, showCourse, now), note = failedNote(r.failed, r.partial), this.setCount("grade", r.value.reduce((s, x) => s + x.count, 0));
        } else if (this.tab === "checkup") {
          let ignored = await loadIgnored(), r = await this.loader.checkup(courses, ignored), ids = new Set(courses.map((c) => c.id)), ignoredHere = [...ignored].filter((k) => ids.has(k.split(":")[0])).length;
          content = checkupView(r.value, ignoredHere, showCourse, (i) => this.ignore(i), () => this.unignore(courses)), note = failedNote(r.failed, r.partial), this.setCount("checkup", r.value.filter((i) => i.severity === "fix").length);
        } else if (this.tab === "students") {
          let r = await this.loader.students(courses, this.opts.settings.missingThreshold);
          this.lastStudents = r.value, content = studentsView({
            rows: r.value,
            courses,
            threshold: this.opts.settings.missingThreshold,
            periodKnown: r.periodKnown,
            namesShown: this.namesShown,
            showCourse,
            onShowNames: () => {
              this.namesShown = !0, this.renderTab();
            },
            onHideNames: () => {
              this.namesShown = !1, this.renderTab();
            },
            onCopy: () => this.copyStudents(),
            onThreshold: (n) => {
              this.opts.settings = { ...this.opts.settings, missingThreshold: n }, saveSettings(this.opts.settings).catch(() => {
              }), this.renderTab();
            }
          }), note = failedNote(r.failed, r.partial);
        } else {
          let r = await this.loader.week(courses);
          content = weekView(r.value, showCourse, now), note = failedNote(r.failed, r.partial);
        }
      } catch {
        content = h("p", { class: "empty" }, "Couldn't load this from Canvas. Click Refresh to try again.");
      }
      token === this.renderToken && (clear(this.body), append(this.body, content, note), this.setStatus(`Updated ${formatDayTime(now).split(", ").pop()}`));
    }
    setCount(tab, n) {
      let b = this.tabButtons.get(tab);
      if (!b) return;
      let label = TABS.find(([t]) => t === tab)[1];
      clear(b), append(b, label, n ? h("span", { class: "n" }, ` ${n}`) : null);
    }
    async ignore(i) {
      let set = await loadIgnored();
      set.add(i.key), await setIgnored(set).catch(() => {
      }), this.renderTab();
    }
    async unignore(courses) {
      let ids = new Set(courses.map((c) => c.id)), set = await loadIgnored();
      for (let k of [...set]) ids.has(k.split(":")[0]) && set.delete(k);
      await setIgnored(set).catch(() => {
      }), this.renderTab();
    }
    async copyStudents() {
      try {
        await navigator.clipboard.writeText(studentsAsText(this.lastStudents)), this.setStatus("List copied");
      } catch {
        this.setStatus("Couldn't copy. Select the names instead.");
      }
    }
  };

  // src/content.ts
  var ROLE_KEY = "rjtt-teaches", BADGE_KEY = "rjtt-badge", BADGE_TTL_MS = 300 * 1e3;
  function courseIdFromPath(path) {
    let m = path.match(/^\/courses\/(\d{1,20})(?:\/|$)/);
    return m ? m[1] : null;
  }
  function isGradingPage(path) {
    return /^\/courses\/\d{1,20}\/gradebook(?:\/|$)/.test(path);
  }
  function readSession(key) {
    try {
      return window.sessionStorage.getItem(key);
    } catch {
      return null;
    }
  }
  function writeSession(key, value) {
    try {
      window.sessionStorage.setItem(key, value);
    } catch {
    }
  }
  async function teachesSomething() {
    let cached = readSession(ROLE_KEY);
    if (cached === "1" || cached === "0") return cached === "1";
    let { items } = await canvasGetAll(
      "/api/v1/courses?enrollment_state=active&include[]=term&per_page=100",
      4
    ), yes = items.some((c) => isCurrentTeachingCourse(c, /* @__PURE__ */ new Date()));
    return writeSession(ROLE_KEY, yes ? "1" : "0"), yes;
  }
  async function badgeCount() {
    try {
      let raw = readSession(BADGE_KEY);
      if (raw) {
        let v = JSON.parse(raw);
        if (typeof v.n == "number" && typeof v.t == "number" && Date.now() - v.t < BADGE_TTL_MS) return v.n;
      }
    } catch {
    }
    let n = await needsGradingCount();
    return n !== null && writeSession(BADGE_KEY, JSON.stringify({ n, t: Date.now() })), n;
  }
  function sendBadge(n) {
    try {
      chrome.runtime.sendMessage({ type: "badge", count: n ?? 0 }).catch(() => {
      });
    } catch {
    }
  }
  async function start() {
    if (!onAllowedOrigin() || window.top !== window) return null;
    let teaches = !1;
    try {
      teaches = await teachesSomething();
    } catch {
      return null;
    }
    if (!teaches) return null;
    let settings = await loadSettings(), path = window.location.pathname, panel = new Panel({
      settings,
      currentCourseId: courseIdFromPath(path),
      showButton: settings.buttonOnGradingPages || !isGradingPage(path),
      openSettings: () => {
        try {
          chrome.runtime.sendMessage({ type: "open-settings" }).catch(() => {
          });
        } catch {
        }
      }
    });
    document.documentElement.appendChild(panel.host), onSettingsChanged((s) => panel.updateSettings(s));
    let n = await badgeCount();
    return panel.setBadge(n), sendBadge(n), panel;
  }
  typeof chrome < "u" && chrome.runtime?.id && start();
})();
