"use strict";
(() => {
  // src/lib/constants.ts
  var ALLOWED_ORIGINS = ["https://rjhs.instructure.com"];

  // src/background.ts
  function fromOurCanvasTab(sender) {
    if (sender.id !== chrome.runtime.id) return !1;
    let url = sender.tab?.url ?? sender.url;
    if (!url) return !1;
    try {
      return ALLOWED_ORIGINS.includes(new URL(url).origin) && sender.frameId === 0;
    } catch {
      return !1;
    }
  }
  chrome.runtime.onMessage.addListener((msg, sender) => {
    if (!fromOurCanvasTab(sender) || !msg || typeof msg != "object") return;
    let m = msg;
    if (m.type === "badge") {
      let n = typeof m.count == "number" && Number.isFinite(m.count) ? Math.max(0, Math.floor(m.count)) : 0;
      chrome.action.setBadgeBackgroundColor({ color: "#C11430" }), chrome.action.setBadgeText({ text: n ? n > 99 ? "99+" : String(n) : "" });
    } else m.type === "open-settings" && chrome.runtime.openOptionsPage();
  });
})();
