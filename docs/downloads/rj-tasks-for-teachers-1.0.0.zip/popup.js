"use strict";
(() => {
  // src/lib/constants.ts
  var FEEDBACK_FORM_URL = "https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=4SwuQZc-CEClZjjFdYLisQzihhIB-7hPp9L3AOSeJONUMFQ0SlRPSTgwQkJCWDM4SkEzNzFPRFZDUi4u", HOMEPAGE_URL = "https://rjedtech.github.io/rj-tasks-for-teachers/";

  // src/pages/popup.ts
  document.getElementById("open-settings")?.addEventListener("click", () => {
    chrome.runtime.openOptionsPage(), window.close();
  });
  var fb = document.getElementById("feedback");
  fb && FEEDBACK_FORM_URL && (fb.href = FEEDBACK_FORM_URL, fb.hidden = !1);
  var home = document.getElementById("homepage");
  home && (home.href = HOMEPAGE_URL);
})();
