"use strict";
(() => {
  // src/lib/constants.ts
  var FEEDBACK_FORM_URL = "https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=4SwuQZc-CEClZjjFdYLisQzihhIB-7hPp9L3AOSeJONUMFQ0SlRPSTgwQkJCWDM4SkEzNzFPRFZDUi4u", HOMEPAGE_URL = "https://rjedtech.github.io/rj-tasks-for-teachers/";

  // src/lib/settings.ts
  var DEFAULTS = {
    missingThreshold: 3,
    hideNames: !0,
    excludedCourses: [],
    buttonOnGradingPages: !1
  }, THRESHOLDS = [1, 2, 3, 4, 5];
  function clean(raw) {
    let r = raw && typeof raw == "object" ? raw : {};
    return {
      missingThreshold: THRESHOLDS.includes(r.missingThreshold) ? r.missingThreshold : DEFAULTS.missingThreshold,
      hideNames: typeof r.hideNames == "boolean" ? r.hideNames : DEFAULTS.hideNames,
      excludedCourses: Array.isArray(r.excludedCourses) ? r.excludedCourses.map(String).filter((s) => /^\d{1,20}$/.test(s)).slice(0, 200) : [],
      buttonOnGradingPages: typeof r.buttonOnGradingPages == "boolean" ? r.buttonOnGradingPages : DEFAULTS.buttonOnGradingPages
    };
  }
  async function loadSettings() {
    try {
      let got = await chrome.storage.sync.get("settings");
      return clean(got.settings);
    } catch {
      return { ...DEFAULTS };
    }
  }
  async function saveSettings(s) {
    await chrome.storage.sync.set({ settings: clean(s) });
  }
  async function loadKnownCourses() {
    try {
      let got = await chrome.storage.local.get("knownCourses");
      return Array.isArray(got.knownCourses) ? got.knownCourses.filter(
        (c) => c && /^\d{1,20}$/.test(String(c.id)) && typeof c.code == "string" && typeof c.name == "string"
      ) : [];
    } catch {
      return [];
    }
  }

  // src/ui/dom.ts
  var ALLOWED_ATTR = /^(class|id|role|type|title|tabindex|hidden|disabled|href|target|rel|value|selected|for|name|open|lang|aria-[a-z]+|data-[a-z-]+)$/;
  function h(tag, attrs = {}, ...children) {
    let el = document.createElement(tag);
    for (let [k, v] of Object.entries(attrs))
      if (!(v == null || v === !1)) {
        if (!ALLOWED_ATTR.test(k)) throw new Error("Refused attribute " + k);
        if (k === "href") {
          el.setAttribute("href", safeLink(String(v)));
          continue;
        }
        el.setAttribute(k, v === !0 ? "" : String(v));
      }
    return append(el, ...children), el;
  }
  function append(el, ...children) {
    for (let c of children)
      c == null || c === !1 || el.appendChild(typeof c == "string" || typeof c == "number" ? document.createTextNode(String(c)) : c);
  }
  function clear(el) {
    for (; el.firstChild; ) el.removeChild(el.firstChild);
  }
  function safeLink(href) {
    try {
      let u = new URL(href, window.location.origin);
      return u.origin === window.location.origin && (u.protocol === "https:" || u.protocol === "http:") ? u.toString() : "#";
    } catch {
      return "#";
    }
  }

  // src/pages/options.ts
  var settings, saved = document.getElementById("saved");
  async function save(next) {
    settings = next;
    try {
      await saveSettings(settings), saved.textContent = "Saved.";
    } catch {
      saved.textContent = "Couldn't save. Try again.";
    }
    window.setTimeout(() => saved.textContent = "", 2500);
  }
  async function init() {
    settings = await loadSettings();
    let th = document.getElementById("threshold");
    for (let n of [1, 2, 3, 4, 5]) {
      let input = h("input", { type: "radio", name: "threshold", value: n });
      input.checked = settings.missingThreshold === n, input.addEventListener("change", () => {
        save({ ...settings, missingThreshold: n });
      }), th.append(h("label", {}, input, h("span", {}, `${n} or more missing${n === 3 ? " (recommended)" : ""}`)));
    }
    let hide = document.getElementById("hideNames");
    hide.checked = settings.hideNames, hide.addEventListener("change", () => {
      save({ ...settings, hideNames: hide.checked });
    });
    let btn = document.getElementById("buttonOnGradingPages");
    btn.checked = settings.buttonOnGradingPages, btn.addEventListener("change", () => {
      save({ ...settings, buttonOnGradingPages: btn.checked });
    });
    let box = document.getElementById("classes"), known = await loadKnownCourses();
    clear(box), known.length || box.append(h("p", { class: "help" }, "Open Canvas and click My Classes once, and your classes will show up here."));
    for (let c of known) {
      let input = h("input", { type: "checkbox" });
      input.checked = !settings.excludedCourses.includes(c.id), input.addEventListener("change", () => {
        let ex = new Set(settings.excludedCourses);
        input.checked ? ex.delete(c.id) : ex.add(c.id), save({ ...settings, excludedCourses: [...ex] });
      }), box.append(h("label", {}, input, h("span", {}, c.code === c.name ? c.name : `${c.code} · ${c.name}`)));
    }
    FEEDBACK_FORM_URL && (document.getElementById("feedback").href = FEEDBACK_FORM_URL, document.getElementById("feedback-box").hidden = !1), document.getElementById("homepage").href = HOMEPAGE_URL;
  }
  init();
})();
