"use strict";
(() => {
  // src/lib/constants.ts
  var PD_URL = "https://rjhs.instructure.com/courses/5414";
  var FEEDBACK_FORM_URL = "https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=4SwuQZc-CEClZjjFdYLisQzihhIB-7hPp9L3AOSeJONUMFQ0SlRPSTgwQkJCWDM4SkEzNzFPRFZDUi4u", HOMEPAGE_URL = "https://rjedtech.github.io/rj-tasks-for-teachers/";

  // src/lib/dates.ts
  var dayFmt = new Intl.DateTimeFormat("en-US", { weekday: "short", month: "short", day: "numeric" }), timeFmt = new Intl.DateTimeFormat("en-US", { hour: "numeric", minute: "2-digit" });

  // src/data/checkup.ts
  var RULE_INFO = [
    { rule: "not_in_module", label: "Every assignment in a module (RJ Baseline 1)", group: "baseline" },
    { rule: "missing_policy", label: "Missing policy on (RJ Baseline 2)", group: "baseline" },
    { rule: "weekly_graded", label: "A graded item every week (RJ Baseline 3)", group: "baseline" },
    { rule: "grading_waiting", label: "Grading waiting 7+ days (RJ Baseline 3)", group: "baseline" },
    { rule: "no_due_date", label: "No due date", group: "fix" },
    { rule: "unpublished_due", label: "Unpublished but due", group: "fix" },
    { rule: "locks_before_due", label: "Locks before it is due", group: "fix" },
    { rule: "opens_after_due", label: "Opens after it is due", group: "fix" },
    { rule: "outside_term", label: "Due date outside this semester", group: "fix" },
    { rule: "rubric_points", label: "Rubric total doesn't match the points", group: "fix" },
    { rule: "weights_total", label: "Group weights don't add up to 100%", group: "fix" },
    { rule: "weights_off", label: "Group weights set but turned off", group: "fix" },
    { rule: "zero_points", label: "Worth 0 points", group: "check" },
    { rule: "midnight_due", label: "Due at 12:00 AM", group: "check" },
    { rule: "weekend_due", label: "Due on a weekend", group: "check" },
    { rule: "zero_weight_group", label: "Graded work in a 0% group", group: "check" },
    { rule: "points_typo", label: "Points far above the rest of its group", group: "check" },
    { rule: "omitted", label: "Set not to count toward the final grade", group: "check" },
    { rule: "duplicate_name", label: "Two assignments with the same name", group: "check" }
  ], ALL_RULES = RULE_INFO.map((r) => r.rule);
  var SHORT = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" });

  // src/lib/settings.ts
  var SECTIONS = ["grade", "checkup", "students", "week"];
  function normalizeOrder(saved2) {
    let out = [];
    if (Array.isArray(saved2))
      for (let x of saved2) SECTIONS.includes(x) && !out.includes(x) && out.push(x);
    for (let x of SECTIONS) out.includes(x) || out.push(x);
    return out;
  }
  var DEFAULTS = {
    missingThreshold: 3,
    hideNames: !0,
    excludedCourses: [],
    buttonOnGradingPages: !1,
    allClasses: !1,
    buttonElsewhere: !0,
    sectionOrder: [...SECTIONS],
    cardHidden: [],
    cardCollapsed: !1,
    checksOff: []
  }, THRESHOLDS = [1, 2, 3, 4, 5];
  function clean(raw) {
    let r = raw && typeof raw == "object" ? raw : {};
    return {
      missingThreshold: THRESHOLDS.includes(r.missingThreshold) ? r.missingThreshold : DEFAULTS.missingThreshold,
      hideNames: typeof r.hideNames == "boolean" ? r.hideNames : DEFAULTS.hideNames,
      excludedCourses: Array.isArray(r.excludedCourses) ? r.excludedCourses.map(String).filter((s) => /^\d{1,20}$/.test(s)).slice(0, 200) : [],
      buttonOnGradingPages: typeof r.buttonOnGradingPages == "boolean" ? r.buttonOnGradingPages : DEFAULTS.buttonOnGradingPages,
      allClasses: typeof r.allClasses == "boolean" ? r.allClasses : DEFAULTS.allClasses,
      buttonElsewhere: typeof r.buttonElsewhere == "boolean" ? r.buttonElsewhere : DEFAULTS.buttonElsewhere,
      sectionOrder: normalizeOrder(r.sectionOrder),
      cardHidden: Array.isArray(r.cardHidden) ? SECTIONS.filter((x) => r.cardHidden.includes(x)) : [],
      cardCollapsed: typeof r.cardCollapsed == "boolean" ? r.cardCollapsed : !1,
      checksOff: Array.isArray(r.checksOff) ? r.checksOff.filter((x) => typeof x == "string" && /^[a-z_]{1,30}$/.test(x)).slice(0, 50) : []
    };
  }
  async function loadSettings() {
    try {
      let got = await chrome.storage.sync.get("settings");
      return clean(got.settings);
    } catch {
      return { ...DEFAULTS };
    }
  }
  async function saveSettings(s) {
    await chrome.storage.sync.set({ settings: clean(s) });
  }
  function onSettingsChanged(fn) {
    try {
      chrome.storage.onChanged.addListener((changes, area) => {
        area === "sync" && changes.settings && fn(clean(changes.settings.newValue));
      });
    } catch {
    }
  }
  async function loadKnownCourses() {
    try {
      let got = await chrome.storage.local.get("knownCourses");
      return Array.isArray(got.knownCourses) ? got.knownCourses.filter(
        (c) => c && /^\d{1,20}$/.test(String(c.id)) && typeof c.code == "string" && typeof c.name == "string"
      ) : [];
    } catch {
      return [];
    }
  }

  // src/ui/dom.ts
  var ALLOWED_ATTR = /^(class|id|role|type|title|tabindex|hidden|disabled|href|target|rel|value|selected|for|name|open|lang|aria-[a-z]+|data-[a-z-]+)$/;
  function h(tag, attrs = {}, ...children) {
    let el = document.createElement(tag);
    for (let [k, v] of Object.entries(attrs))
      if (!(v == null || v === !1)) {
        if (!ALLOWED_ATTR.test(k)) throw new Error("Refused attribute " + k);
        if (k === "href") {
          el.setAttribute("href", safeLink(String(v)));
          continue;
        }
        el.setAttribute(k, v === !0 ? "" : String(v));
      }
    return append(el, ...children), el;
  }
  function append(el, ...children) {
    for (let c of children)
      c == null || c === !1 || el.appendChild(typeof c == "string" || typeof c == "number" ? document.createTextNode(String(c)) : c);
  }
  function clear(el) {
    for (; el.firstChild; ) el.removeChild(el.firstChild);
  }
  function safeLink(href) {
    try {
      let u = new URL(href, window.location.origin);
      return u.origin === window.location.origin && (u.protocol === "https:" || u.protocol === "http:") ? u.toString() : "#";
    } catch {
      return "#";
    }
  }

  // src/dark.ts
  var DARK_KEY = "dark_canvas", LIGHT_PAGES_KEY = "dark_light_pages";
  var HIDE_BAR_KEY = "rj-dark-bar-hidden", CLASS_NAME = "rj-dark-canvas", FORM_URL = "https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=4SwuQZc-CEClZjjFdYLisQzihhIB-7hPp9L3AOSeJONUMFQ0SlRPSTgwQkJCWDM4SkEzNzFPRFZDUi4u", FORM_CHOICE_ID = "r72d16c9e6f7c4827b3edbc412f9b16aa", FORM_CHOICE = "Dark mode problem: something is hard to read or missing", FORM_PAGE_ID = "r036011aeca9b49629186c9d66aa4dff5", PAGE_FLIP = "invert(.93) hue-rotate(180deg)", FLIP_BACK = "invert(1) hue-rotate(180deg)", CSS = `@media screen {
html.${CLASS_NAME} { background: #fff !important; filter: ${PAGE_FLIP} !important; }
html.${CLASS_NAME} img, html.${CLASS_NAME} video, html.${CLASS_NAME} iframe,
html.${CLASS_NAME} embed, html.${CLASS_NAME} object, html.${CLASS_NAME} canvas { filter: ${FLIP_BACK} !important; }
html.${CLASS_NAME} img, html.${CLASS_NAME} iframe, html.${CLASS_NAME} embed, html.${CLASS_NAME} object { background: #fff !important; }
html.${CLASS_NAME} img.equation_image { filter: none !important; background: transparent !important; }
html.${CLASS_NAME} #header, html.${CLASS_NAME} .ic-app-header, html.${CLASS_NAME} .ic-DashboardCard__header_image,
html.${CLASS_NAME} [data-rj-dark-bar] { filter: ${FLIP_BACK} !important; }
html.${CLASS_NAME} #header img, html.${CLASS_NAME} .ic-app-header img { filter: none !important; background: transparent !important; }
}`, BAR_CSS = `
:host { all: initial; position: fixed; left: 50%; transform: translateX(-50%); bottom: 12px; z-index: 2147482000; max-width: calc(100vw - 24px); }
.bar { display: flex; flex-wrap: wrap; align-items: center; gap: 4px 8px; padding: 5px 8px 5px 14px; border: 1px solid #c7cdd1; border-radius: 18px; background: #fff; color: #273540; box-shadow: 0 1px 4px rgba(0,0,0,.25); font: 13px/1.4 "Lato Extended", Lato, "Helvetica Neue", Helvetica, Arial, sans-serif; }
a, button { color: #0e68b3; font: inherit; }
button { padding: 0; border: 0; background: none; cursor: pointer; text-decoration: underline; }
button.x { width: 22px; height: 22px; color: #5b6870; font-size: 16px; line-height: 1; text-decoration: none; }
:focus-visible { outline: 2px solid #0e68b3; outline-offset: 2px; }
`;
  function staysLight(path, title) {
    return /\/gradebook(\/|$)/.test(path) || /\/courses\/\d+\/quizzes\/\d+/.test(path) || /\/courses\/\d+\/assignments\/\d+\/(build|take|moderate|reports|exports|settings)(\/|$)/.test(path) || /\/moderate(\/|$)/.test(path) || /^Quizzes\b/.test(title);
  }
  function reportUrl(page) {
    return `${FORM_URL}&${FORM_CHOICE_ID}=${encodeURIComponent(`"${FORM_CHOICE}"`)}&${FORM_PAGE_ID}=${encodeURIComponent(page)}`;
  }
  function start() {
    if (window.top !== window || window.location.origin !== "https://rjhs.instructure.com") return;
    let html = document.documentElement, style = document.createElement("style");
    style.textContent = CSS, html.appendChild(style);
    let enabled = !1, lightPages = [], bar = null, path = () => window.location.pathname, barHidden = () => {
      try {
        return window.sessionStorage.getItem(HIDE_BAR_KEY) === "1";
      } catch {
        return !1;
      }
    }, setPageLight = (light) => {
      let others = lightPages.filter((p) => p !== path());
      lightPages = (light ? [...others, path()] : others).slice(-300), chrome.storage.local.set({ [LIGHT_PAGES_KEY]: lightPages }), update();
    }, link = (text, onClick) => {
      let b = document.createElement("button");
      return b.type = "button", b.textContent = text, b.addEventListener("click", onClick), b;
    }, drawBar = (pageLight) => {
      if (bar?.remove(), bar = null, !document.body || barHidden()) return;
      let host = document.createElement("div");
      host.setAttribute("data-rj-dark-bar", "");
      let root = host.attachShadow({ mode: "open" }), css = document.createElement("style");
      css.textContent = BAR_CSS;
      let box = document.createElement("div");
      box.className = "bar", box.setAttribute("role", "region"), box.setAttribute("aria-label", "Dark mode");
      let report = document.createElement("a");
      report.textContent = "Report it", report.href = reportUrl(window.location.origin + path()), report.target = "_blank", report.rel = "noopener noreferrer";
      let close = link("×", () => {
        try {
          window.sessionStorage.setItem(HIDE_BAR_KEY, "1");
        } catch {
        }
        drawBar(pageLight);
      });
      close.className = "x", close.setAttribute("aria-label", "Hide this message for now");
      let message = document.createElement("span");
      message.textContent = pageLight ? "This page is in light mode." : "Something hard to read?", box.append(
        message,
        pageLight ? link("Back to dark mode", () => setPageLight(!1)) : link("Show this page in light mode", () => setPageLight(!0)),
        report,
        close
      ), document.body.classList.contains("is-masquerading-or-student-view") && (host.style.bottom = "56px"), root.append(css, box), document.body.appendChild(host), bar = host;
    }, update = () => {
      let forced = staysLight(path(), document.title), pageLight = lightPages.includes(path());
      html.classList.toggle(CLASS_NAME, enabled && !forced && !pageLight), enabled && !forced ? drawBar(pageLight) : (bar?.remove(), bar = null);
    };
    chrome.storage.sync.get(DARK_KEY, (sync) => {
      enabled = sync[DARK_KEY] === !0, chrome.storage.local.get(LIGHT_PAGES_KEY, (local) => {
        let saved2 = local[LIGHT_PAGES_KEY];
        lightPages = Array.isArray(saved2) ? saved2.filter((p) => typeof p == "string") : [], update();
      });
    }), chrome.storage.onChanged.addListener((changes, area) => {
      area === "sync" && DARK_KEY in changes && (enabled = changes[DARK_KEY].newValue === !0, update());
    }), document.addEventListener("DOMContentLoaded", () => {
      update();
      let title = document.querySelector("head > title");
      title && new MutationObserver(update).observe(title, { childList: !0, characterData: !0, subtree: !0 });
    });
  }
  typeof chrome < "u" && chrome.storage && start();

  // src/pages/options.ts
  var settings, saved = document.getElementById("saved");
  document.getElementById("done").addEventListener("click", () => window.close());
  async function save(next) {
    settings = next;
    try {
      await saveSettings(settings), saved.textContent = "Saved.";
    } catch {
      saved.textContent = "Couldn't save. Try again.";
    }
    window.setTimeout(() => saved.textContent = "", 2500);
  }
  async function init() {
    settings = await loadSettings();
    let th = document.getElementById("threshold");
    for (let n of [1, 2, 3, 4, 5]) {
      let input = h("input", { type: "radio", name: "threshold", value: n });
      input.checked = settings.missingThreshold === n, input.addEventListener("change", () => {
        save({ ...settings, missingThreshold: n });
      }), th.append(h("label", {}, input, h("span", {}, `${n} or more missing${n === 3 ? " (recommended)" : ""}`)));
    }
    let hide = document.getElementById("hideNames");
    hide.checked = settings.hideNames, hide.addEventListener("change", () => {
      save({ ...settings, hideNames: hide.checked });
    });
    let btn = document.getElementById("buttonOnGradingPages");
    btn.checked = settings.buttonOnGradingPages, btn.addEventListener("change", () => {
      save({ ...settings, buttonOnGradingPages: btn.checked });
    });
    let sem = document.getElementById("semesterOnly");
    sem.checked = !settings.allClasses, sem.addEventListener("change", () => {
      save({ ...settings, allClasses: !sem.checked });
    });
    let elsewhere = document.getElementById("buttonElsewhere");
    elsewhere.checked = settings.buttonElsewhere, elsewhere.addEventListener("change", () => {
      save({ ...settings, buttonElsewhere: elsewhere.checked });
    });
    let dark = document.getElementById("darkCanvas");
    chrome.storage.sync.get(DARK_KEY, (r) => dark.checked = r[DARK_KEY] === !0), dark.addEventListener("change", () => {
      chrome.storage.sync.set({ [DARK_KEY]: dark.checked }, () => {
        saved.textContent = chrome.runtime.lastError ? "Couldn't save. Try again." : "Saved.", window.setTimeout(() => saved.textContent = "", 2500);
      });
    }), renderOrder();
    let collapsed = document.getElementById("cardCollapsed");
    collapsed.checked = settings.cardCollapsed, collapsed.addEventListener("change", () => {
      save({ ...settings, cardCollapsed: collapsed.checked });
    }), renderChecks(), document.getElementById("checks-all").addEventListener("click", () => {
      save({ ...settings, checksOff: [] }).then(renderChecks);
    }), document.getElementById("pd").href = PD_URL, document.getElementById("reset-order").addEventListener("click", () => {
      save({ ...settings, sectionOrder: [...SECTIONS] }).then(() => {
        renderOrder(), announce("Order reset: To grade, Check-up, Students, Week.");
      });
    });
    let box = document.getElementById("classes"), known = await loadKnownCourses();
    clear(box), known.length || box.append(h("p", { class: "help" }, "Open Canvas and click My Classes once, and your classes will show up here. (After changing “Only this semester’s classes,” open My Classes again to refresh this list.)"));
    for (let c of known) {
      let input = h("input", { type: "checkbox", "data-course": c.id });
      input.checked = !settings.excludedCourses.includes(c.id), input.addEventListener("change", () => {
        let ex = new Set(settings.excludedCourses);
        input.checked ? ex.delete(c.id) : ex.add(c.id), save({ ...settings, excludedCourses: [...ex] });
      }), box.append(h("label", {}, input, h("span", {}, c.code === c.name ? c.name : `${c.code} · ${c.name}`)));
    }
    FEEDBACK_FORM_URL && (document.getElementById("feedback").href = FEEDBACK_FORM_URL, document.getElementById("feedback-box").hidden = !1), document.getElementById("homepage").href = HOMEPAGE_URL, onSettingsChanged((s) => {
      settings = s;
      let set = (id, v) => document.getElementById(id).checked = v;
      set("hideNames", s.hideNames), set("buttonOnGradingPages", s.buttonOnGradingPages), set("buttonElsewhere", s.buttonElsewhere), set("semesterOnly", !s.allClasses), set("cardCollapsed", s.cardCollapsed), document.querySelectorAll("#threshold input").forEach((r) => r.checked = Number(r.value) === s.missingThreshold), document.querySelectorAll("#classes input[data-course]").forEach((c) => c.checked = !s.excludedCourses.includes(c.dataset.course));
      let active = document.activeElement, move = active?.getAttribute("data-move"), rule = active?.getAttribute("data-rule"), sec = active?.getAttribute("data-sec");
      renderOrder(), renderChecks();
      let again = move ? document.querySelector(`[data-move="${move}"]`) : rule ? document.querySelector(`#checks [data-rule="${rule}"]`) : sec ? document.querySelector(`#order [data-sec="${sec}"]`) : null;
      again && !again.disabled && again.focus();
    });
  }
  function renderChecks() {
    let box = document.getElementById("checks");
    clear(box);
    let groups = [
      ["baseline", "RJ Baseline"],
      ["fix", "Setup problems (to fix)"],
      ["check", "Worth a look"]
    ];
    for (let [g, title] of groups) {
      let part = h("div", { class: "group", role: "group", "aria-label": title }, h("p", { class: "gtitle" }, title));
      for (let r of RULE_INFO.filter((x) => x.group === g)) {
        let cb = h("input", { type: "checkbox", "data-rule": r.rule });
        cb.checked = !settings.checksOff.includes(r.rule), cb.addEventListener("change", () => {
          let off = new Set(settings.checksOff);
          cb.checked ? off.delete(r.rule) : off.add(r.rule), save({ ...settings, checksOff: RULE_INFO.map((x) => x.rule).filter((x) => off.has(x)) });
        }), part.append(h("label", {}, cb, h("span", {}, r.label)));
      }
      box.append(part);
    }
  }
  var LABELS = { grade: "To grade", checkup: "Check-up", students: "Students", week: "Week" };
  function announce(msg) {
    let el = document.getElementById("order-status");
    el.textContent = "", window.setTimeout(() => el.textContent = msg, 50);
  }
  function renderOrder(focus) {
    let list = document.getElementById("order");
    clear(list);
    let order = settings.sectionOrder;
    if (order.forEach((id, i) => {
      let cb = h("input", { type: "checkbox", "data-sec": id });
      cb.checked = !settings.cardHidden.includes(id), cb.addEventListener("change", () => {
        let hidden = new Set(settings.cardHidden);
        cb.checked ? hidden.delete(id) : hidden.add(id), save({ ...settings, cardHidden: SECTIONS.filter((x) => hidden.has(x)) });
      });
      let move = (dir) => {
        let j = dir === "up" ? i - 1 : i + 1;
        if (j < 0 || j >= order.length) return;
        let next = [...order];
        [next[i], next[j]] = [next[j], next[i]], save({ ...settings, sectionOrder: next }), renderOrder({ id, dir }), announce(`${LABELS[id]} is now number ${j + 1} of ${order.length}.`);
      }, up = h("button", { type: "button", class: "arrow", "aria-label": `Move ${LABELS[id]} up`, disabled: i === 0, "data-move": `${id}-up` }, "↑"), down = h("button", { type: "button", class: "arrow", "aria-label": `Move ${LABELS[id]} down`, disabled: i === order.length - 1, "data-move": `${id}-down` }, "↓");
      up.addEventListener("click", () => move("up")), down.addEventListener("click", () => move("down")), list.append(h("li", {}, h("div", { class: "orow" }, h("label", {}, cb, h("span", {}, LABELS[id])), h("span", { class: "arrows" }, up, down))));
    }), focus) {
      let want = list.querySelector(`[data-move="${focus.id}-${focus.dir}"]`), other = list.querySelector(`[data-move="${focus.id}-${focus.dir === "up" ? "down" : "up"}"]`);
      (want && !want.disabled ? want : other)?.focus();
    }
  }
  init();
})();
