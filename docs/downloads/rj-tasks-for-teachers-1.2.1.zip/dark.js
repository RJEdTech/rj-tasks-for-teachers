"use strict";
(() => {
  // src/dark.ts
  var DARK_KEY = "dark_canvas", LIGHT_PAGES_KEY = "dark_light_pages";
  var HIDE_BAR_KEY = "rj-dark-bar-hidden", CLASS_NAME = "rj-dark-canvas", FORM_URL = "https://forms.cloud.microsoft/Pages/ResponsePage.aspx?id=4SwuQZc-CEClZjjFdYLisQzihhIB-7hPp9L3AOSeJONUMFQ0SlRPSTgwQkJCWDM4SkEzNzFPRFZDUi4u", FORM_CHOICE_ID = "r72d16c9e6f7c4827b3edbc412f9b16aa", FORM_CHOICE = "Dark mode problem: something is hard to read or missing", FORM_PAGE_ID = "r036011aeca9b49629186c9d66aa4dff5", PAGE_FLIP = "invert(.93) hue-rotate(180deg)", FLIP_BACK = "invert(1) hue-rotate(180deg)", CSS = `@media screen {
html.${CLASS_NAME} { background: #fff !important; filter: ${PAGE_FLIP} !important; }
html.${CLASS_NAME} img, html.${CLASS_NAME} video, html.${CLASS_NAME} iframe,
html.${CLASS_NAME} embed, html.${CLASS_NAME} object, html.${CLASS_NAME} canvas { filter: ${FLIP_BACK} !important; }
html.${CLASS_NAME} img, html.${CLASS_NAME} iframe, html.${CLASS_NAME} embed, html.${CLASS_NAME} object { background: #fff !important; }
html.${CLASS_NAME} img.equation_image { filter: none !important; background: transparent !important; }
html.${CLASS_NAME} #header, html.${CLASS_NAME} .ic-app-header, html.${CLASS_NAME} .ic-DashboardCard__header_image,
html.${CLASS_NAME} [data-rj-dark-bar] { filter: ${FLIP_BACK} !important; }
html.${CLASS_NAME} #header img, html.${CLASS_NAME} .ic-app-header img { filter: none !important; background: transparent !important; }
}`, BAR_CSS = `
:host { all: initial; position: fixed; left: 50%; transform: translateX(-50%); bottom: 12px; z-index: 2147482000; max-width: calc(100vw - 24px); }
.bar { display: flex; flex-wrap: wrap; align-items: center; gap: 4px 8px; padding: 5px 8px 5px 14px; border: 1px solid #c7cdd1; border-radius: 18px; background: #fff; color: #273540; box-shadow: 0 1px 4px rgba(0,0,0,.25); font: 13px/1.4 "Lato Extended", Lato, "Helvetica Neue", Helvetica, Arial, sans-serif; }
a, button { color: #0e68b3; font: inherit; }
button { padding: 0; border: 0; background: none; cursor: pointer; text-decoration: underline; }
button.x { width: 22px; height: 22px; color: #5b6870; font-size: 16px; line-height: 1; text-decoration: none; }
:focus-visible { outline: 2px solid #0e68b3; outline-offset: 2px; }
`;
  function staysLight(path, title) {
    return /\/gradebook(\/|$)/.test(path) || /\/courses\/\d+\/quizzes\/\d+/.test(path) || /\/courses\/\d+\/assignments\/\d+\/(build|take|moderate|reports|exports|settings)(\/|$)/.test(path) || /\/moderate(\/|$)/.test(path) || /^Quizzes\b/.test(title);
  }
  function reportUrl(page) {
    return `${FORM_URL}&${FORM_CHOICE_ID}=${encodeURIComponent(`"${FORM_CHOICE}"`)}&${FORM_PAGE_ID}=${encodeURIComponent(page)}`;
  }
  function start() {
    if (window.top !== window || window.location.origin !== "https://rjhs.instructure.com") return;
    let html = document.documentElement, style = document.createElement("style");
    style.textContent = CSS, html.appendChild(style);
    let enabled = !1, lightPages = [], bar = null, path = () => window.location.pathname, barHidden = () => {
      try {
        return window.sessionStorage.getItem(HIDE_BAR_KEY) === "1";
      } catch {
        return !1;
      }
    }, setPageLight = (light) => {
      let others = lightPages.filter((p) => p !== path());
      lightPages = (light ? [...others, path()] : others).slice(-300), chrome.storage.local.set({ [LIGHT_PAGES_KEY]: lightPages }), update();
    }, link = (text, onClick) => {
      let b = document.createElement("button");
      return b.type = "button", b.textContent = text, b.addEventListener("click", onClick), b;
    }, drawBar = (pageLight) => {
      if (bar?.remove(), bar = null, !document.body || barHidden()) return;
      let host = document.createElement("div");
      host.setAttribute("data-rj-dark-bar", "");
      let root = host.attachShadow({ mode: "open" }), css = document.createElement("style");
      css.textContent = BAR_CSS;
      let box = document.createElement("div");
      box.className = "bar", box.setAttribute("role", "region"), box.setAttribute("aria-label", "Dark mode");
      let report = document.createElement("a");
      report.textContent = "Report it", report.href = reportUrl(window.location.origin + path()), report.target = "_blank", report.rel = "noopener noreferrer";
      let close = link("×", () => {
        try {
          window.sessionStorage.setItem(HIDE_BAR_KEY, "1");
        } catch {
        }
        drawBar(pageLight);
      });
      close.className = "x", close.setAttribute("aria-label", "Hide this message for now");
      let message = document.createElement("span");
      message.textContent = pageLight ? "This page is in light mode." : "Something hard to read?", box.append(
        message,
        pageLight ? link("Back to dark mode", () => setPageLight(!1)) : link("Show this page in light mode", () => setPageLight(!0)),
        report,
        close
      ), document.body.classList.contains("is-masquerading-or-student-view") && (host.style.bottom = "56px"), root.append(css, box), document.body.appendChild(host), bar = host;
    }, update = () => {
      let forced = staysLight(path(), document.title), pageLight = lightPages.includes(path());
      html.classList.toggle(CLASS_NAME, enabled && !forced && !pageLight), enabled && !forced ? drawBar(pageLight) : (bar?.remove(), bar = null);
    };
    chrome.storage.sync.get(DARK_KEY, (sync) => {
      enabled = sync[DARK_KEY] === !0, chrome.storage.local.get(LIGHT_PAGES_KEY, (local) => {
        let saved = local[LIGHT_PAGES_KEY];
        lightPages = Array.isArray(saved) ? saved.filter((p) => typeof p == "string") : [], update();
      });
    }), chrome.storage.onChanged.addListener((changes, area) => {
      area === "sync" && DARK_KEY in changes && (enabled = changes[DARK_KEY].newValue === !0, update());
    }), document.addEventListener("DOMContentLoaded", () => {
      update();
      let title = document.querySelector("head > title");
      title && new MutationObserver(update).observe(title, { childList: !0, characterData: !0, subtree: !0 });
    });
  }
  typeof chrome < "u" && chrome.storage && start();
})();
